package com.Ticket.BookingService.Service;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Formatter;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.Ticket.BookingService.Controller.RecordNotFoundException;
import com.Ticket.BookingService.Entity.AddShow;
import com.Ticket.BookingService.Entity.BookTickets;
import com.Ticket.BookingService.Entity.Booking;
import com.Ticket.BookingService.Entity.Bookingdetails;
import com.Ticket.BookingService.Entity.GetShow;
import com.Ticket.BookingService.Entity.Movie;
import com.Ticket.BookingService.Entity.Show;
import com.Ticket.BookingService.Entity.Theatre;
import com.Ticket.BookingService.Entity.User;
import com.Ticket.BookingService.Repository.BookingRepository;
import com.Ticket.BookingService.Repository.MovieRepository;
import com.Ticket.BookingService.Repository.ShowRepository;
import com.Ticket.BookingService.Repository.TheatreRepository;
import com.Ticket.BookingService.Repository.UserRepository;
import com.Ticket.BookingService.model.Report;

@Service
public class BookingService {

	@Autowired
	MovieRepository mrepo;
	@Autowired
	TheatreRepository trepo;
	@Autowired
	ShowRepository srepo;
	@Autowired
	UserRepository urepo;
	@Autowired
	BookingRepository brepo;

	public ResponseEntity<Show> Addshow(AddShow show) {
		
		 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");  
		   LocalDate now = LocalDate.now();  
		   System.out.println(dtf.format(now));  
		   
		   DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			 LocalDate date1 = LocalDate.parse(show.getShowdate(), formatter2); 
			
			 LocalTime presentlocal=LocalTime.now();
			 DateTimeFormatter timef=DateTimeFormatter.ofPattern("HH:mm");
			
			 LocalTime showtime=LocalTime.parse(show.getShowtime(),timef);


		String message = null;
	
		Movie movie = new Movie();
		

		movie = mrepo.findByMovieName(show.getMoviename());
		System.out.println(movie.getMovieId());
		 LocalDate moviedate=LocalDate.parse(movie.getReleaseDate(), formatter2);
		mrepo.save(movie);
		
		System.out.println("release date"+moviedate);
		System.out.println("present time"+presentlocal);
		System.out.println("show time"+showtime);
		Theatre theatre = new Theatre();
		
		theatre = trepo.findByTheatreName(show.getTheatrename());
		int seatcapacity=Integer.parseInt(theatre.getSeatCapacity());
       try {
		if (movie != null && theatre != null && show.getSeatsavailable()>0 && show.getSeatsavailable()<=seatcapacity  && (date1.isAfter(now) || date1.isEqual(now)) && (date1.isAfter(moviedate) || date1.isEqual(moviedate)) ) {
			if(! date1.isEqual(now)) {
						
			Show newshow = new Show();

			newshow.setMovieId(movie);
			

			newshow.setShowdate(show.getShowdate());
			newshow.setShowtime(show.getShowtime());
			newshow.setSeatsavailable(show.getSeatsavailable());
			newshow.setRate(show.getRate());

			
			newshow.setMovieId(movie);
		
			newshow.setTheatreId(theatre);


			srepo.save(newshow);
			message = "show added successfully!!";
			return ResponseEntity.ok(newshow);
			}
			else if(showtime.isAfter(presentlocal)){
				Show newshow = new Show();
				newshow.setMovieId(movie);
				newshow.setShowdate(show.getShowdate());
				newshow.setShowtime(show.getShowtime());
				newshow.setSeatsavailable(show.getSeatsavailable());
				newshow.setRate(show.getRate());				
				newshow.setMovieId(movie);
				newshow.setTheatreId(theatre);
				srepo.save(newshow);
				message = "show added successfully!!";
				return ResponseEntity.ok(newshow);
				
				
				}
			else {
				return ResponseEntity.badRequest().build();
				
			}
		} else {
			 return ResponseEntity.badRequest().build();

			
		}
		}catch(Exception e) {
			 return ResponseEntity.badRequest().build();
			
		}
		

	}
	
	/*
	 * public addbooking(BookTickets bookticket) { String message = null; Booking
	 * booking = new Booking();
	 * 
	 * 
	 * 
	 * }
	 */

	
	public ResponseEntity<Booking> AddBooking(BookTickets bookticket)
	
	 { 
		 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");  
		   LocalDate now = LocalDate.now();  
		   System.out.println(dtf.format(now));
		      
		   DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 
			 LocalDate date1 = LocalDate.parse(bookticket.getShowdate(), formatter2); 
			 LocalTime presentlocal=LocalTime.now();
			 DateTimeFormatter timef=DateTimeFormatter.ofPattern("HH:mm");
			 LocalTime showtime=LocalTime.parse(bookticket.getShowtime(),timef);
		 
		 String message = null;
	     Booking booking = new Booking();
	     booking.setSeatsbooked(bookticket.getSeatsBooked());
	     User user =urepo.findByUserName(bookticket.getUsername());
	      int amount;
	      Iterable<Show> shows =srepo.findAll();

	  try {
	  for (Show show : shows) 
	  { 
	  if(show.getMovieId().getMovieName().equalsIgnoreCase(bookticket.getMoviename()) && show.getTheatreId().getTheatreName().equalsIgnoreCase(bookticket.getTheatrename()))
	  { 
		  System.out.println("inside first if");
		  if(show.getShowdate().equals(bookticket.getShowdate()) &&show.getShowtime().equals(bookticket.getShowtime()))
		  {   
			  
			  if(show.getSeatsavailable() >= bookticket.getSeatsBooked()) 
			  {
				  if(date1.isAfter(now) || date1.isEqual(now)) {
					  if(! date1.isEqual(now)) {
					  
			  	booking.setUserId(user);
			  		booking.setShowid(show);
			  			booking.setSeatsbooked(bookticket.getSeatsBooked());
			  			amount = show.getRate()*booking.getSeatsbooked();
			  		
			  			booking.setAmount(amount);
			  			booking.setBookingstatus("booking confirmed"); 
			  			brepo.save(booking);
			  			message = "booking confirmed!!";
			  			show.setSeatsavailable(show.getSeatsavailable() -
			  			booking.getSeatsbooked());
			  			
			  			 return ResponseEntity.ok(booking);
					  }
					  else if(showtime.isAfter(presentlocal)){
							booking.setUserId(user);
					  		booking.setShowid(show);
					  			booking.setSeatsbooked(bookticket.getSeatsBooked());
					  			amount = show.getRate()*booking.getSeatsbooked();
					  		
					  			booking.setAmount(amount);
					  			booking.setBookingstatus("booking confirmed"); 
					  			brepo.save(booking);
					  			message = "booking confirmed!!";
					  			show.setSeatsavailable(show.getSeatsavailable() -
					  			booking.getSeatsbooked());
					  			
					  			 return ResponseEntity.ok(booking);
						  
					  }
					
					  }
//				  return ResponseEntity.badRequest().build();
			  		 
	  
	             }
			
			  
			  }
		 
					/*
					 * else { message = "seats not available!!"; }
					 */
		      }
	 
				/*
				 * else { message="show is not available for the time"; }
				 */
		  }
	  
			/*
			 * else { message = "movie and threatre is not available!!"; }
			 */
	  
	  if(message.equals("booking confirmed!!")) {
		  return ResponseEntity.ok(booking);
	  }
	  else {
		  return ResponseEntity.badRequest().build();
	  }
	  }
	  catch(Exception e) {
		 return ResponseEntity.badRequest().build();
		  
	  }
	
	  }
	


	public List<GetShow> getallshows() {
			
		   
//		   DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy"); 
//			 LocalDate date1 = LocalDate.parse(bookticket.getShowdate(), formatter2); 
		

		Iterable<Show> shows = srepo.findAll();
		List<GetShow> showlist = new ArrayList<>();

		
		 for (Show show : shows) { 
		GetShow getshow = new GetShow();
		 getshow.setMoviename(show.getMovieId().getMovieName());
		  getshow.setRate(show.getRate());
		 getshow.setSeatsavailable(show.getSeatsavailable());
		 getshow.setShowdate(show.getShowdate());
		 getshow.setShowtime(show.getShowtime());
		getshow.setTheatrename(show.getTheatreId().getTheatreName());
		 getshow.setShowid(show.getShowid());
		  
		 showlist.add(getshow);
		 }
		
		return showlist;
	}
	
	
	
	public List<Bookingdetails> getallbookings() {
		List<Bookingdetails> list = new ArrayList<>();
		List<Booking> bookinglist = new ArrayList<>();
		Iterable<Booking> booking = brepo.findAll();
		
	
		
		
		  for (Booking book : booking) { 
			  if(! book.getBookingstatus().equalsIgnoreCase("cancelled")) {
				  Bookingdetails booklist=new Bookingdetails();
				  booklist.setAmount(book.getAmount());
				  booklist.setBookingid(book.getBookingid());
				  booklist.setMoviename(book.getShowid().getMovieId().getMovieName());
				  booklist.setSeatsbooked(book.getSeatsbooked());
				  booklist.setShowdate(book.getShowid().getShowdate());
				  booklist.setShowtime(book.getShowid().getShowtime());
				  booklist.setTheatrename(book.getShowid().getTheatreId().getTheatreName());
				  booklist.setUsername(book.getUserId().getUserName());
				  booklist.setBookingstatus(book.getBookingstatus());
//		  bookinglist.add(book);
				  list.add(booklist);
		  
		  
		  }
		  
		  }
		  
			/*
			 * Bookingdetails bookdetails = new Bookingdetails();
			 * bookdetails.setAmount(book.getAmount());
			 * bookdetails.setBookingid(book.getBookingid());
			 * bookdetails.setMoviename(book.getShowid().getMovieId().getMovieName());
			 * bookdetails.setSeatsbooked(book.getSeatsbooked());
			 * bookdetails.setShowdate(book.getShowid().getShowdate());
			 * bookdetails.setShowtime(book.getShowid().getShowtime());
			 * bookdetails.setTheatrename(book.getShowid().getTheatreId().getTheatreName());
			 * bookdetails.setUsername(book.getUserId().getUserName());
			 * list.add(bookdetails);
			 */
		  
		 
		 
		return list;
	}
	
	
  public ResponseEntity<List<Bookingdetails>> deleteBooking(int bookingid) {
		String message = null;
		Optional<Booking> booking = brepo.findById(bookingid);
		Booking newbooking=new Booking();
	 try {
		if (booking.isPresent()) {
			
			if (!(booking.get().getBookingstatus().equalsIgnoreCase("cancelled"))) {
				newbooking.setAmount(booking.get().getAmount());
				newbooking.setBookingid(booking.get().getBookingid());
				newbooking.setBookingstatus("cancelled");
				newbooking.setSeatsbooked(booking.get().getSeatsbooked());
				
				Show show = booking.get().getShowid();
				int seatsavailable = show.getSeatsavailable();
				show.setSeatsavailable(booking.get().getSeatsbooked() + show.getSeatsavailable());
				newbooking.setShowid(show);
				newbooking.setUserId(booking.get().getUserId());
			
				/* booking.get().setBookingstatus("cancelled"); */
				message = "booking cancelled successfully";
				brepo.save(newbooking);
				List<Bookingdetails> list = new ArrayList<>();
				List<Booking> bookinglist = new ArrayList<>();
				Iterable<Booking> bookings = brepo.findAll();
					
				  for (Booking book : bookings) { 
					  if(! book.getBookingstatus().equalsIgnoreCase("cancelled")) {
						  Bookingdetails booklist=new Bookingdetails();
						  booklist.setAmount(book.getAmount());
						  booklist.setBookingid(book.getBookingid());
						  booklist.setMoviename(book.getShowid().getMovieId().getMovieName());
						  booklist.setSeatsbooked(book.getSeatsbooked());
						  booklist.setShowdate(book.getShowid().getShowdate());
						  booklist.setShowtime(book.getShowid().getShowtime());
						  booklist.setTheatrename(book.getShowid().getTheatreId().getTheatreName());
						  booklist.setUsername(book.getUserId().getUserName());
						  booklist.setBookingstatus(book.getBookingstatus());
//				  bookinglist.add(book);
						  list.add(booklist);
				  
				  
				  }
				  
				  }
				return ResponseEntity.ok(list);
			}
		
			return ResponseEntity.badRequest().build();
			/* message = "already cancelled"; */
		}
		return ResponseEntity.badRequest().build();
		}catch(Exception e){
			return ResponseEntity.badRequest().build();
			}
		
	
		/*else
			message = "booking id is not exist!!";*/

	 }

	



	
	  public ResponseEntity<List<GetShow>> deleteshowbyid(int id) {
	   String message=null;
	 try {
	 if( srepo.existsById(id)) {
		 
		 Iterable<Booking> bookings=brepo.findAll();
		 for(Booking book:bookings) {
			 if(book.getShowid()!=null ) {
				 if(book.getShowid().getShowid()==id) {
					 if(book.getBookingstatus().equalsIgnoreCase("cancelled")) {
						 Show show=null;
						 book.setShowid(show);
						 brepo.save(book);
					 }
					 
				 }
				 
			 }
			 
		 }
		 
		 
		 
		 srepo.deleteById(id);
		 
		 message="show deleted succesfully";
		 Iterable<Show> shows = srepo.findAll();
			List<GetShow> showlist = new ArrayList<>();

			
			 for (Show show : shows) { 
			GetShow getshow = new GetShow();
			 getshow.setMoviename(show.getMovieId().getMovieName());
			  getshow.setRate(show.getRate());
			 getshow.setSeatsavailable(show.getSeatsavailable());
			 getshow.setShowdate(show.getShowdate());
			 getshow.setShowtime(show.getShowtime());
			getshow.setTheatrename(show.getTheatreId().getTheatreName());
			 getshow.setShowid(show.getShowid());
			  
			 showlist.add(getshow);
			 }
		 return ResponseEntity.ok(showlist);
	 }
	 else {
		 return ResponseEntity.badRequest().build();
		
	 }
	 }catch(Exception e) {
		 return ResponseEntity.badRequest().build();
	 }
	  }
	  
	  
	  public ResponseEntity<Show> getShowById(int showid) {
		  Optional<Show> show=srepo.findById(showid);
		  try {
				if(show.isPresent()) {
//					System.out.println("inside if");
					return ResponseEntity.ok(show.get());
				}else {
					return ResponseEntity.badRequest().build();
				}
				}catch(Exception e) {
					 return ResponseEntity.badRequest().build();
				}
	  }
	  
	  
	  public ResponseEntity<GetShow> getdisplayShowById(int showid){
		  Optional<Show> show=srepo.findById(showid);
		  Show show1=new Show();
		  
		  try {
				if(show.isPresent()) {
//					System.out.println("inside if");
					show1=show.get();
					GetShow newshow=new GetShow();
					newshow.setMoviename(show1.getMovieId().getMovieName());
					newshow.setRate(show1.getRate());
					newshow.setSeatsavailable(show1.getSeatsavailable());
					newshow.setShowdate(show1.getShowdate());
					newshow.setShowid(show1.getShowid());
					newshow.setShowtime(show1.getShowtime());
					newshow.setTheatrename(show1.getTheatreId().getTheatreName());
					return ResponseEntity.ok(newshow);
				}else {
					return ResponseEntity.badRequest().build();
				}
				}catch(Exception e) {
					 return ResponseEntity.badRequest().build();
				}
		  
	  }
	

	
	  public ResponseEntity<Show> updateshowbyid(GetShow show,int showid) { 
		 
		  Optional<Show> show1=srepo.findById(showid);
		  Show upshow=new Show();
		  try {
			  if(show1.isPresent()) {
				  Show newshow=show1.get();
				  Movie movie1=mrepo.findByMovieName(show.getMoviename());
				  Theatre theatre2=trepo.findByTheatreName(show.getTheatrename());
				  newshow.setMovieId(movie1);
				  newshow.setTheatreId(theatre2);
				  
/*//				  Optional<Movie> movie=mrepo.findById(newshow.getMovieId().getMovieId());
*///				  if(movie.isPresent()) {
//					 Movie newmovie=movie.get();
//					 newmovie.setMovieId(show.getMovieId().getMovieId());
//					 newmovie.setMovieName(show.getMovieId().getMovieName());
//					 newmovie.setRating(show.getMovieId().getRating());
//					 newmovie.setReleaseDate(show.getMovieId().getReleaseDate());
//					 newshow.setMovieId(newmovie);
//				}else {
//					 return ResponseEntity.badRequest().build();
//				}
					/*
					 * Optional<Theatre>
					 * theatre=trepo.findById(newshow.getTheatreId().getTheatreId());
					 */
//				  if(theatre.isPresent()) {
//					  Theatre newtheatre=theatre.get();
//					  newtheatre.setTheatreId(show.getTheatreId().getTheatreId());
//					  newtheatre.setTheatreName(show.getTheatreId().getTheatreName());
//					  newtheatre.setLocation(show.getTheatreId().getLocation());
//					  newtheatre.setSeatCapacity(show.getTheatreId().getSeatCapacity());
//					  newshow.setTheatreId(newtheatre);
//			   }else {
//				   return ResponseEntity.badRequest().build();
//			   }
//				  
				  newshow.setRate(show.getRate());
				  newshow.setSeatsavailable(show.getSeatsavailable());
				  newshow.setShowdate(show.getShowdate());
				  newshow.setShowtime(show.getShowtime());
				  newshow.setShowid(show.getShowid());
				 upshow=newshow;
				 
				 srepo.save(newshow);
				  return ResponseEntity.ok(newshow);
				  
				  
				  
			  }
			  return ResponseEntity.badRequest().build();
			  
			  
		  }catch(Exception e) {
			  return ResponseEntity.badRequest().build();
		  }
		  
//		  Show show1=srepo.findById(show.getShowid()).get();
//		  show1.setMovieId(movieId);
			/* Show show1=srepo.findById(show.getShowid()); */
		/* newshow.setMovieId(); */
	 
	
	 
	  }
	  
	  public List<GetShow> getShowByMovie(String Moviename){
		  
		  Iterable<Show> shows=srepo.findAll();
		  List<Show> movieshows=new ArrayList();
		  List<GetShow> moviegetshow=new ArrayList();
		  for(Show show:shows) {
			  if(show.getMovieId().getMovieName().equalsIgnoreCase(Moviename)) {
				  
				  GetShow show1=new GetShow();
				  show1.setMoviename(show.getMovieId().getMovieName());
				  show1.setRate(show.getRate());
				  show1.setSeatsavailable(show.getSeatsavailable());
				  show1.setShowdate(show.getShowdate());
				  show1.setShowtime(show.getShowtime());
				  show1.setShowid(show.getShowid());
				  show1.setTheatrename(show.getTheatreId().getTheatreName());
				  moviegetshow.add(show1);
				  
			  }
			  
		  }
		  return moviegetshow;
	  }
	  
	  
	  public List<GetShow> getShowByTheatre(String theatrename){
		 
		
		  Iterable<Show> shows=srepo.findAll();
		  List<Show> movieshows=new ArrayList();
		  List<GetShow> moviegetshow=new ArrayList();
		  for(Show show:shows) {
			  if(show.getTheatreId().getTheatreName().equalsIgnoreCase(theatrename)) {
				  
				  GetShow show1=new GetShow();
				  show1.setMoviename(show.getMovieId().getMovieName());
				  show1.setRate(show.getRate());
				  show1.setSeatsavailable(show.getSeatsavailable());
				  show1.setShowdate(show.getShowdate());
				  show1.setShowtime(show.getShowtime());
				  show1.setShowid(show.getShowid());
				  show1.setTheatrename(show.getTheatreId().getTheatreName());
				  moviegetshow.add(show1);
				  
			  }
			  
		  }
		  return moviegetshow;
	  }
	  
	  
	  
	  public ResponseEntity<List<Report>> getreport(String fromdate,String enddate) {
		  Iterable<Booking> bookings=brepo.findAll();
		  try {
				
			  DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 
				 LocalDate strtdate1 = LocalDate.parse(fromdate, formatter);
				 DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 
				 LocalDate enddate1 = LocalDate.parse(enddate, formatter);
			  List<Report> filteredlist=new ArrayList();
				
			
			  for(Booking booking:bookings) {
				  DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 

				  if(booking.getShowid()!=null) {
					 LocalDate date1 = LocalDate.parse(booking.getShowid().getShowdate(), formatter2);
					 System.out.println(date1);
					 System.out.println(strtdate1);
					 System.out.println(enddate1);
					 
					
						 System.out.println(date1);
				  System.out.println("-----------------");
				  if( date1.isAfter(strtdate1)  && date1.isBefore(enddate1)) {
					  if(booking.getUserId()!=null) {
					  System.out.println("-----------inside if-----------");
					  Report report=new Report();
					  report.setAmount(booking.getAmount());
					  report.setBookingid(booking.getBookingid());
					  report.setBookingstatus(booking.getBookingstatus());
					  report.setMoviename(booking.getShowid().getMovieId().getMovieName());
					  report.setSeatsbooked(booking.getSeatsbooked());
					  report.setShowdate(booking.getShowid().getShowdate());
					  report.setShowid(booking.getShowid().getShowid());
					  report.setShowtime(booking.getShowid().getShowtime());
					  report.setTheatrename(booking.getShowid().getTheatreId().getTheatreName());
					  report.setUsername(booking.getUserId().getUserName());
					  filteredlist.add(report);
					  
					  }
					  else {
						  Report report=new Report();
						  report.setAmount(booking.getAmount());
						  report.setBookingid(booking.getBookingid());
						  report.setBookingstatus(booking.getBookingstatus());
						  report.setMoviename(booking.getShowid().getMovieId().getMovieName());
						  report.setSeatsbooked(booking.getSeatsbooked());
						  report.setShowdate(booking.getShowid().getShowdate());
						  report.setShowid(booking.getShowid().getShowid());
						  report.setShowtime(booking.getShowid().getShowtime());
						  report.setTheatrename(booking.getShowid().getTheatreId().getTheatreName());
						  report.setUsername("not available");
						  filteredlist.add(report);
					  }
					  
					  
				  }
				  
			  }}
			  return ResponseEntity.ok(filteredlist);
			  
		 
		  }catch(Exception e) {
			  return ResponseEntity.badRequest().build();
		  }
		  }
	  
	  
	  public List<Bookingdetails> getbookingbyuser(String username){
		  Iterable<Booking> allbookings=brepo.findAll();
		  List<Bookingdetails> bookinglist=new ArrayList();
		 
		  for(Booking book:allbookings) {
			  if(book.getUserId()!=null && book.getShowid()!=null){
			  if(book.getUserId().getUserName().equalsIgnoreCase(username)) {
				  Bookingdetails booking=new Bookingdetails();
				  booking.setAmount(book.getAmount());
				  booking.setBookingid(book.getBookingid());
				  booking.setMoviename(book.getShowid().getMovieId().getMovieName());
				  booking.setSeatsbooked(book.getSeatsbooked());
				  booking.setShowdate(book.getShowid().getShowdate());
				  booking.setShowtime(book.getShowid().getShowtime());
				  booking.setTheatrename(book.getShowid().getTheatreId().getTheatreName());
				  booking.setUsername(book.getUserId().getUserName());
				  booking.setBookingstatus(book.getBookingstatus());
				  bookinglist.add(booking);
				  
				  
			  }
			  }
			
//				 else if(book.getShowid()==null && book.getUserId()!=null) { 
//				 if(book.getUserId().getUserName().equalsIgnoreCase(username)) { 
//				  Bookingdetails booking=new Bookingdetails();
//				  booking.setAmount(book.getAmount()); 
//				  booking.setBookingid(book.getBookingid()); //
////				  booking.setMoviename(book.getShowid().getMovieId().getMovieName()); //
//				  booking.setSeatsbooked(book.getSeatsbooked()); //
////				  booking.setShowdate(book.getShowid().getShowdate()); //
////				  booking.setShowtime(book.getShowid().getShowtime()); //
////				  booking.setTheatrename(book.getShowid().getTheatreId().getTheatreName()); //
//				  booking.setUsername(book.getUserId().getUserName()); //
//				  booking.setBookingstatus(book.getBookingstatus()); //
//				  bookinglist.add(booking); // // //
//				  }
//				  
//				  }
				 		  }
		  
		  return bookinglist;
		  
		  
	  }
	  

	  
	  public ResponseEntity<String> deactiveuser(int userid) {
		  Iterable<Booking> allbookings=brepo.findAll();	
		  try {
		  for(Booking book:allbookings) {
			  if(book.getUserId()!=null && book.getShowid()!=null) {
		  if(book.getUserId().getUserId()==userid){
			  User user1=null;
			  book.setUserId(user1);
			  Show show=book.getShowid();
			  show.setSeatsavailable(book.getSeatsbooked()+show.getSeatsavailable());
			  System.out.println(userid);
			  System.out.println(book.getUserId());
			  System.out.println(book.getUserId());
			  book.setShowid(show);
			  book.setBookingstatus("cancelled");
			  brepo.save(book);
			 
			  
			  }
			  }
			  		  }
		  urepo.deleteById(userid);
		  return ResponseEntity.ok("");
		  }catch(Exception e) {
			  return ResponseEntity.badRequest().build();
		  } 
	  }
	  
	  
	  
	  public Iterable<Movie> deleteMovieByMovieName(String moviename){
		    Iterable<Show> shows=srepo.findAll();
		    Iterable<Booking> bookings=brepo.findAll();
		    for(Show show:shows) {
		    	if(show.getMovieId().getMovieName().equalsIgnoreCase(moviename)) {
		    		for(Booking booking:bookings) {
		    			if(booking.getShowid()!=null) {
		    				
		    			if(booking.getShowid().getShowid()==show.getShowid()) {
		    				Show newshow=null;
		    				booking.setShowid(newshow);
		    				//show.setSeatsavailable(booking.getSeatsbooked()+show.getSeatsavailable());
		    				booking.setBookingstatus("cancelled");
//		    				brepo.save(booking);
		    				brepo.delete(booking);
		    				
		    				
		    			}
		    		}
		    		}
		    		srepo.delete(show);
		    		
		    	}
		    	
		    }
		    
		  
			 mrepo.deleteByMovieName(moviename);
			 return mrepo.findAll();
			
			
		}
	  
	  
	  public Iterable<Theatre> deleteByName(String theatrename){
		  Iterable<Show> shows=srepo.findAll();
		    Iterable<Booking> bookings=brepo.findAll();
		    for(Show show:shows) {
		    	if(show.getTheatreId().getTheatreName().equalsIgnoreCase(theatrename)) {
		    		for(Booking booking:bookings) {
		    			if(booking.getShowid()!=null) {
		    				
		    			if(booking.getShowid().getShowid()==show.getShowid()) {
		    				Show newshow=null;
		    				booking.setShowid(newshow);
		    				//show.setSeatsavailable(booking.getSeatsbooked()+show.getSeatsavailable());
		    				booking.setBookingstatus("cancelled");
//		    				brepo.save(booking);
		    				brepo.delete(booking);
		    				
		    				
		    			}
		    		}
		    		}
		    		srepo.delete(show);
		    		
		    	}
		    	
		    }
		 
			trepo.deleteByTheatreName(theatrename);
			return trepo.findAll();
		}

	  
	  
	  
}
