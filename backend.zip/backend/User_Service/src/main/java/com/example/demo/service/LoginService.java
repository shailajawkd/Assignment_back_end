package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.UserDTO;
import com.example.demo.dto.UserLogin;
import com.example.demo.entity.Role;
import com.example.demo.entity.User;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.UserRepository;

@Service
public class LoginService {

	@Autowired
	UserRepository repo;

	@Autowired
	RoleRepository rolerepo;

	/*
	 * public List<User> getAllUser(){ List<User> users= new ArrayList<User>();
	 * repo.findAll().forEach(users::add);
	 * 
	 * return users; }
	 */

	public User createUser(User user) throws Exception {
		String tempusername = user.getUserName();
		User userobj = null;
		if (tempusername != null && !"".equals(tempusername)) {
			 userobj = repo.findByUserName(tempusername);
			if (userobj != null) {
				throw new Exception("user with " + tempusername + " is already exist");
			}

		}
		
		userobj = repo.save(user);

		/* System.out.println(user.getEmail()); */
		User useren = new User();
		Role roleen = new Role();
		useren.setEmail(user.getEmail());
		useren.setPassword(user.getPassword());
		useren.setPhoneNumber(user.getPhoneNumber());
		/* useren.setUserId(user.getUserId()); */
		useren.setUserName(user.getUserName());

		Role role2 = new Role();

		role2.setUserRole(user.getRole1().getUserRole());
		/* rolerepo.save(role2); */

		useren.setRole1(role2);
		
		return userobj;

	}

	public List<User> getAllusers() {

		
		  List<User> userlist= new ArrayList<>();
//		  repo.findAll().forEach(users::add); Iterable<User> users =repo.findAll();
//		  users.forEach(userlist::add); return userlist;
		 

		/* List<UserDTO> userlist = new ArrayList(); */

		Iterable<User> user = repo.findAll();
		for (User user1 : user) {
			if(user1.getRole1().getUserRole().equalsIgnoreCase("user")) {
			User user2 = new User();
			user2.setUserId(user1.getUserId());
			user2.setEmail(user1.getEmail());
			user2.setPassword(user1.getPassword());
			user2.setPhoneNumber(user1.getPhoneNumber());
			user2.setUserName(user1.getUserName());

			user2.setRole1(user1.getRole1());

			userlist.add(user2);
			}
		}

		/*
		 * Iterable<User> user =repo.findAll(); user.forEach(userlist::add);
		 */
		return userlist;

	}

	/*
	 * public UserDTO getUser(int username) { UserDTO user1=null; Optional<User>
	 * optuser=repo.findById(username); if(optuser.isPresent()) { User
	 * user=optuser.get(); user1.setEmail(user.getEmail());
	 * user1.setPassword(user.getPassword());
	 * user1.setPhoneNumber(user.getPhoneNumber());
	 * user1.setUserId(user.getUserId()); user1.setUserName(user.getUserName());
	 * 
	 * }
	 * 
	 * return user1;
	 */

	public User getUserByUserName(String username) {

		return repo.findByUserName(username);

	}

	public Iterable<User> deleteUserByUsername(String username) {

		repo.deleteByUserName(username);
		return repo.findAll();
	}

	public User updateUser(User user,String username) {
		User newuser=repo.findByUserName(username);
		newuser.setEmail(user.getEmail());
		newuser.setPassword(user.getPassword());
		newuser.setPhoneNumber(user.getPhoneNumber());
		Optional<Role> role=rolerepo.findById(user.getRole1().getUserRole());
		newuser.setRole1(role.get());
		newuser.setUserId(user.getUserId());
		newuser.setUserName(user.getUserName());
		
		return repo.save(newuser);
	}

	public User LoginUser(User newuser) throws Exception {
		User user = repo.findByUserName(newuser.getUserName());
		String tempusername = newuser.getUserName();
		String temppassword = newuser.getPassword();
		String message;
		User userobj = null;
		if (tempusername != null && temppassword != null) {
			userobj = repo.findByUserNameAndPassword(tempusername, temppassword);
		}
		if (userobj == null) {
			throw new Exception("Bad Credentials");
		}
	
		
		return userobj;
	}
	/* Optional<User> optuser=repo.findById(user.getUsername()); */
	/*
	 * User user=new User(); if(optuser.isPresent()) {
	 * 
	 * }
	 */
}
