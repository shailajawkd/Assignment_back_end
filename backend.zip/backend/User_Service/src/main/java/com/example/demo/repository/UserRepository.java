package com.example.demo.repository;





import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.User;

@Repository
public interface UserRepository extends CrudRepository<User,Integer> {
	
	public Iterable<User> deleteByUserName(String userName);
	
	public User findByUserName(String userName);
	
	public User findByUserNameAndPassword(String userName,String password);
	


}
