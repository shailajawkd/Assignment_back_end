package com.Ticket.MovieService.Entity;


import java.sql.Time;
import java.util.Date;

public class Sample {
	
	private int id;
	private Date sampledate;
	private Time sampletime;
	private String name;
	

}
