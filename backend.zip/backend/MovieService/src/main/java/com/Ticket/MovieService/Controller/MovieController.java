package com.Ticket.MovieService.Controller;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.Ticket.MovieService.Entity.Movie;
import com.Ticket.MovieService.Repository.MovieRepository;
import com.Ticket.MovieService.Service.MovieService;
import com.Ticket.MovieService.model.MoviesList;


@RestController
@CrossOrigin
public class MovieController {
	
	@Autowired
	MovieRepository mrepo;
	@Autowired
	MovieService mser;
	
	@GetMapping(value="/AllMovies")
	@Transactional
	public List<Movie> getAllMovies(){
		
		
		
		return mser.getAllMovies();
	}
	
	@PostMapping(value="/addmovie")
	@Transactional
	public ResponseEntity<Movie> addMovie(@RequestBody Movie movie) {
		
		return mser.addMovie(movie);
		
	}
	@GetMapping(value="/getmovie/{moviename}")
	@Transactional
	public Movie getMovieByMovieName(@PathVariable String moviename) {
	
		Movie  movie=new Movie();
		movie=mser.getByMovieName(moviename);
		return movie;
		
	}
	@GetMapping(value="/delete/{moviename}")
	@Transactional
	public Iterable<Movie> deleteByMovieName(@PathVariable String moviename){
		
		return mser.deleteMovieByMovieName(moviename);
		
	}
	@RequestMapping(method=RequestMethod.PUT, value="/movie/{movieid}")
	public Movie updateMovie(@RequestBody Movie movie,@PathVariable int movieid) {
		
		return mser.updateMovie(movie,movieid);
		
		
	}
	@GetMapping(value="/getmovie1/{id}")
	@Transactional
	public ResponseEntity<Movie> getbyid(@PathVariable int id) {
		return mser.getbyid(id);
		
	}
	
	

}
