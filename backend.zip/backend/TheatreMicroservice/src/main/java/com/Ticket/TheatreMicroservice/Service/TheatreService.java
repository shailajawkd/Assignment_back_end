package com.Ticket.TheatreMicroservice.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import com.Ticket.TheatreMicroservice.Entity.Theatre;
import com.Ticket.TheatreMicroservice.Repository.TheatreRepository;



@Service
public class TheatreService {
	
	@Autowired
	TheatreRepository trepo;
	

	public List<Theatre> getAllTheatres(){
		
		List<Theatre> alltheatres=new ArrayList<>();
		
		Iterable<Theatre> theatres=trepo.findAll();
		theatres.forEach(alltheatres::add);
		
		return alltheatres;
		
	}
	
	public ResponseEntity<Theatre> addTheatre(Theatre theatre) {
		Iterable<Theatre> alltheatres=trepo.findAll();
		
		try {
			for(Theatre theatre1:alltheatres) {
				if(theatre1.getTheatreName().equalsIgnoreCase(theatre.getTheatreName())) {
					 return ResponseEntity.badRequest().build();
					
				}
				
			}
			Theatre newtheatre=trepo.save(theatre);
			
			return ResponseEntity.ok(newtheatre);
			
		}catch(Exception e) {
			 return ResponseEntity.badRequest().build();
		}
		
		/*
		 * trepo.save(theatre); return "Theatre added successfully";
		 */
		
	}
	
	public Theatre getByTheatreName(String theatrename) {
		return trepo.findByTheatreName(theatrename);
		
		
	}
	
	public Iterable<Theatre> deleteByName(String theatrename){
		trepo.deleteByTheatreName(theatrename);
		return trepo.findAll();
	}

	
	/*
	 * public userServiceEntity updateDetails(userServiceEntity user) { return
	 * repo.save(user);
	 */

	public Theatre updateTheatre(Theatre theatre,int id) {
		
		Optional<Theatre> theatre1=trepo.findById(id);
		Theatre newtheatre=new Theatre();
		if(theatre1.isPresent()) {
//			newmovie=movie1.get();
			newtheatre.setTheatreId(theatre.getTheatreId());
			newtheatre.setTheatreName(theatre.getTheatreName());
			newtheatre.setLocation(theatre.getLocation());
			newtheatre.setSeatCapacity(theatre.getSeatCapacity());
			
			
		}

		   return  trepo.save(newtheatre);
//		   return  trepo.save(theatre);
		

		
		
		/*
		 * Theatre newtheatre=new Theatre();
		 * 
		 * Optional<Theatre> opttheatre=trepo.findById(id); if(opttheatre.isPresent()) {
		 * newtheatre.setLocation(theatre.getLocation());
		 * newtheatre.setSeatCapacity(theatre.getSeatCapacity());
		 * newtheatre.setTheatreId(theatre.getTheatreId());
		 * newtheatre.setTheatreName(theatre.getTheatreName());
		 * 
		 * } else {
		 * 
		 * }
		 */
		
		
	}
	
	public ResponseEntity<Theatre> getByid(int id) {
		Optional<Theatre> theatre=trepo.findById(id);
		try {
		if(theatre.isPresent()) {
//			System.out.println("inside if");
			return ResponseEntity.ok(theatre.get());
		}else {
			return ResponseEntity.badRequest().build();
		}
		}catch(Exception e) {
			 return ResponseEntity.badRequest().build();
		}
		
	}
	
}
