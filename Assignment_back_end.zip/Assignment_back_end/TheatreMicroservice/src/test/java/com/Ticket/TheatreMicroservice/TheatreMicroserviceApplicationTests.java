package com.Ticket.TheatreMicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheatreMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
