package com.Ticket.TheatreMicroservice.Controller;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.Ticket.TheatreMicroservice.Entity.Theatre;
import com.Ticket.TheatreMicroservice.Service.TheatreService;


@RestController
public class TheatreController {
	@Autowired
	TheatreService tserv;
	
	@GetMapping(value="/alltheatres")
	@Transactional
	public List<Theatre> getAllTheatres(){
		return tserv.getAllTheatres();
		
	}
	
	@GetMapping(value="/gettheatre/{theatrename}")
	@Transactional
	public Theatre getTheatreByTheatreName(@PathVariable String theatrename) {
		return tserv.getByTheatreName(theatrename);
		
	}
	@PostMapping(value="/addtheatre")
	@Transactional
	public String addTheatre(@RequestBody Theatre theatre) {
		return tserv.addTheatre(theatre);
		
	}
	@GetMapping(value="/delete/{theatrename}")
	@Transactional
	public Iterable<Theatre> deleteTheatre(@PathVariable String theatrename){
		return tserv.deleteByName(theatrename);
		
	}
	@RequestMapping(method=RequestMethod.PUT, value="/theatre/{theatrename}")
	public Theatre updateTheatre(@RequestBody Theatre theatre,@PathVariable String theatrename) {
		
		return tserv.updateTheatre(theatre);
		
		
	}
	
	
	/*
	 * @RequestMapping(method=RequestMethod.PUT, value="/user/{username}") public
	 * userServiceEntity updateDetails(@RequestBody userServiceEntity user){ return
	 * service.updateDetails(user);
	 * 
	 * }
	 */

}
