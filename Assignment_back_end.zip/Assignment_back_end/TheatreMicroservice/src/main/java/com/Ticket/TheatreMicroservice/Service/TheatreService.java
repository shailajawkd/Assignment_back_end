package com.Ticket.TheatreMicroservice.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ticket.TheatreMicroservice.Entity.Theatre;
import com.Ticket.TheatreMicroservice.Repository.TheatreRepository;



@Service
public class TheatreService {
	
	@Autowired
	TheatreRepository trepo;
	

	public List<Theatre> getAllTheatres(){
		
		List<Theatre> alltheatres=new ArrayList<>();
		
		Iterable<Theatre> theatres=trepo.findAll();
		theatres.forEach(alltheatres::add);
		
		return alltheatres;
		
	}
	
	public String addTheatre(Theatre theatre) {
		trepo.save(theatre);
		return "Theatre added successfully";
		
	}
	
	public Theatre getByTheatreName(String theatrename) {
		return trepo.findByTheatreName(theatrename);
		
		
	}
	
	public Iterable<Theatre> deleteByName(String theatrename){
		trepo.deleteByTheatreName(theatrename);
		return trepo.findAll();
	}

	
	/*
	 * public userServiceEntity updateDetails(userServiceEntity user) { return
	 * repo.save(user);
	 */

	public Theatre updateTheatre(Theatre theatre) {
		   return  trepo.save(theatre);
		

		
		
		/*
		 * Theatre newtheatre=new Theatre();
		 * 
		 * Optional<Theatre> opttheatre=trepo.findById(id); if(opttheatre.isPresent()) {
		 * newtheatre.setLocation(theatre.getLocation());
		 * newtheatre.setSeatCapacity(theatre.getSeatCapacity());
		 * newtheatre.setTheatreId(theatre.getTheatreId());
		 * newtheatre.setTheatreName(theatre.getTheatreName());
		 * 
		 * } else {
		 * 
		 * }
		 */
		
		
	}
	
}
