package com.Ticket.MovieService.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.Ticket.MovieService.Entity.Movie;


@Repository
public interface MovieRepository extends CrudRepository<Movie,Integer>{
	
	public Iterable<Movie> deleteByMovieName(String movieName);
	
	public Movie findByMovieName(String movieName);

}
