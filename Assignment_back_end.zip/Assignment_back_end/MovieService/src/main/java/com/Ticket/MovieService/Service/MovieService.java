package com.Ticket.MovieService.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.Ticket.MovieService.Entity.Movie;
import com.Ticket.MovieService.Repository.MovieRepository;
import com.Ticket.MovieService.model.MoviesList;

@Service
public class MovieService {
	@Autowired
	MovieRepository mrepo;
	
	public MoviesList getAllMovies(){
		
		List<Movie> allmovies=new ArrayList<>();
		
		Iterable<Movie> movies=mrepo.findAll();
		movies.forEach(allmovies::add);
		MoviesList list=new MoviesList();
		list.setMovies(allmovies);
		 return list;
		
	}
	
	
	public String addMovie(Movie movie) {
		
		mrepo.save(movie);
		return "Movie added successfully!!";
	}
	
	public Iterable<Movie> deleteMovieByMovieName(String moviename){
		 mrepo.deleteByMovieName(moviename);
		 return mrepo.findAll();
		
		
	}
	
	public Movie getByMovieName(String moviename) {
		
		return mrepo.findByMovieName(moviename);
	}
	public Movie updateMovie(Movie movie) {
		   return  mrepo.save(movie);
	}

}
