package com.Ticket.BookingService.Entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;



@Entity
public class Role {
	
	@Id
	/* @Column(name = "user_role", nullable = false) */
	private String userRole;
	

	/*
	 * public User getUsers() { return users; }
	 * 
	 * public void setUsers(User users) { this.users = users; }
	 */


    @OneToMany(mappedBy="role1")
    private List<User> users;
	

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	/*
	 * public List<User> getUser() { return user; }
	 * 
	 * public void setUser(List<User> user) { this.user = user; }
	 */
	

}
