package com.Ticket.BookingService.Service;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Formatter;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.Ticket.BookingService.Controller.RecordNotFoundException;
import com.Ticket.BookingService.Entity.AddShow;
import com.Ticket.BookingService.Entity.BookTickets;
import com.Ticket.BookingService.Entity.Booking;
import com.Ticket.BookingService.Entity.Bookingdetails;
import com.Ticket.BookingService.Entity.GetShow;
import com.Ticket.BookingService.Entity.Movie;
import com.Ticket.BookingService.Entity.Show;
import com.Ticket.BookingService.Entity.Theatre;
import com.Ticket.BookingService.Entity.User;
import com.Ticket.BookingService.Repository.BookingRepository;
import com.Ticket.BookingService.Repository.MovieRepository;
import com.Ticket.BookingService.Repository.ShowRepository;
import com.Ticket.BookingService.Repository.TheatreRepository;
import com.Ticket.BookingService.Repository.UserRepository;

@Service
public class BookingService {

	@Autowired
	MovieRepository mrepo;
	@Autowired
	TheatreRepository trepo;
	@Autowired
	ShowRepository srepo;
	@Autowired
	UserRepository urepo;
	@Autowired
	BookingRepository brepo;

	public String Addshow(AddShow show) {

		/* srepo.save(show); */
		/* String message=null; */

		String message = null;
		System.out.println("before movie--------------");
		Movie movie = new Movie();
		System.out.println(show.getMoviename());

		movie = mrepo.findByMovieName(show.getMoviename());
		System.out.println(movie.getMovieId());
		mrepo.save(movie);
		System.out.println("before theatre--------------");
		Theatre theatre = new Theatre();
		theatre = trepo.findByTheatreName(show.getTheatrename());

		if (movie != null && theatre != null) {
			System.out.println("inside if--------------");
			Show newshow = new Show();
			System.out.println(movie.getMovieId());
			System.out.println(movie.getMovieName());
			System.out.println(movie.getRating());
			System.out.println(movie.getReleaseDate());
			newshow.setMovieId(movie);

			/* newshow.getMovieId().setMovieId(movie.getMovieId()); */
			/*
			 * System.out.println("movieid"+newshow.getMovieId().getMovieId());
			 * newshow.getMovieId().setMovieName(movie.getMovieName());
			 * System.out.println("moviename");
			 * newshow.getMovieId().setRating(movie.getRating());
			 * System.out.println("movierating");
			 * newshow.getMovieId().setReleaseDate(movie.getReleaseDate());
			 * System.out.println("releasedate");
			 */
			newshow.setShowdate(show.getShowdate());
			newshow.setShowtime(show.getShowtime());
			newshow.setSeatsavailable(show.getAvailableseats());
			newshow.setRate(show.getRate());

			/* System.out.println("aftershowtime=-=============="); */
			newshow.setMovieId(movie);
			/*
			 * System.out.println("aftr movie");
			 * System.out.println(newshow.getMovieId().getRating());
			 */
			newshow.setTheatreId(theatre);

			/*
			 * newshow.getTheatreId().setTheatreId(theatre.getTheatreId());
			 * 
			 * System.out.println("theatre is");
			 * newshow.getTheatreId().setLocation(theatre.getLocation());
			 * System.out.println("theatre id"+newshow.getTheatreId().getLocation());
			 * newshow.getTheatreId().setSeatCapacity(theatre.getSeatCapacity());
			 * newshow.getTheatreId().setTheatreName(theatre.getTheatreName());
			 */

			srepo.save(newshow);
			message = "show added successfully!!";
		} else {

			message = "movie and theatre are not present in list!!";
		}
		return message;

	}
	
	/*
	 * public addbooking(BookTickets bookticket) { String message = null; Booking
	 * booking = new Booking();
	 * 
	 * 
	 * 
	 * }
	 */

	
	 public String AddBooking(BookTickets bookticket)
	 { 
		 String message = null;
	  Booking booking = new Booking();
	 booking.setSeatsbooked(bookticket.getSeatsBooked());
	 User user =urepo.findByUserName(bookticket.getUsername());
	 System.out.println("after user");
	 int amount;
	 Iterable<Show> shows =srepo.findAll();
	 System.out.println("after show");
	  
	  for (Show show : shows) 
	  { 
		  System.out.println(bookticket.getMoviename());
	  System.out.println(show.getMovieId().getMovieName()); 
	  if(show.getMovieId().getMovieName().equalsIgnoreCase(bookticket.getMoviename()) && show.getTheatreId().getTheatreName().equalsIgnoreCase(bookticket.getTheatrename()))
	  { 
		  System.out.println("inside first if");
		  if(show.getShowdate().equals(bookticket.getShowdate()) &&show.getShowtime().equals(bookticket.getShowtime()))
		  {
			  if(show.getSeatsavailable() > bookticket.getSeatsBooked()) 
			  {
			  	booking.setUserId(user);
			  		booking.setShowid(show);
			  			booking.setSeatsbooked(bookticket.getSeatsBooked());
			  			amount = show.getRate();
			  			booking.getSeatsbooked(); 
			  			booking.setAmount(amount);
			  			booking.setBookingstatus("booking confirmed"); 
			  			brepo.save(booking);
			  			message = "booking confirmed!!";
			  			show.setSeatsavailable(show.getSeatsavailable() -
			  			booking.getSeatsbooked());
	  
	  } 
		  else
	  { 
		  message = "seats not available!!"; 
		  }
		  } 
	  else { 
		  message="show is not available for the time";
		  } }
	  
	  else {
		  message = "movie and threatre is not available!!"; 
	  } 
	  }
	  
	  return message;
	  }
	


	public Iterable<Show> getallshows() {

		Iterable<Show> shows = srepo.findAll();
		List<GetShow> showlist = new ArrayList<>();

		/*
		 * for (Show show : shows) { GetShow getshow = new GetShow();
		 * getshow.setMoviename(show.getMovieId().getMovieName());
		 * getshow.setRate(show.getRate());
		 * getshow.setSeatsavailable(show.getSeatsavailable());
		 * getshow.setShowdate(show.getShowdate());
		 * getshow.setShowtime(show.getShowtime());
		 * getshow.setTheatrename(show.getTheatreId().getTheatreName());
		 * getshow.setShowid(show.getShowid());
		 * 
		 * showlist.add(getshow);
		 */
		/* } */
		return shows;
	}
	
		public List<Booking> getallbookings() {
		List<Bookingdetails> list = new ArrayList<>();
		List<Booking> bookinglist = new ArrayList<>();
		Iterable<Booking> booking = brepo.findAll();
		
	
		
		
		  for (Booking book : booking) { 
			  if(! book.getBookingstatus().equalsIgnoreCase("cancelled")) {
		  bookinglist.add(book);
		  
		  }
		  
		  
		  
			/*
			 * Bookingdetails bookdetails = new Bookingdetails();
			 * bookdetails.setAmount(book.getAmount());
			 * bookdetails.setBookingid(book.getBookingid());
			 * bookdetails.setMoviename(book.getShowid().getMovieId().getMovieName());
			 * bookdetails.setSeatsbooked(book.getSeatsbooked());
			 * bookdetails.setShowdate(book.getShowid().getShowdate());
			 * bookdetails.setShowtime(book.getShowid().getShowtime());
			 * bookdetails.setTheatrename(book.getShowid().getTheatreId().getTheatreName());
			 * bookdetails.setUsername(book.getUserId().getUserName());
			 * list.add(bookdetails);
			 */
		  
		 }
		 
		return bookinglist;
	}
	
	
		public ResponseEntity<Booking> deleteBooking(int bookingid) {
		String message = null;
		Optional<Booking> booking = brepo.findById(bookingid);
		Booking newbooking=new Booking();
	 try {
		if (booking.isPresent()) {
			
			if (!(booking.get().getBookingstatus().equalsIgnoreCase("cancelled"))) {
				newbooking.setAmount(booking.get().getAmount());
				newbooking.setBookingid(booking.get().getBookingid());
				newbooking.setBookingstatus("cancelled");
				newbooking.setSeatsbooked(booking.get().getSeatsbooked());
				
				Show show = booking.get().getShowid();
				int seatsavailable = show.getSeatsavailable();
				show.setSeatsavailable(booking.get().getSeatsbooked() + show.getSeatsavailable());
				newbooking.setShowid(show);
				newbooking.setUserId(booking.get().getUserId());
			
				/* booking.get().setBookingstatus("cancelled"); */
				message = "booking cancelled successfully";
				brepo.save(newbooking);
				return ResponseEntity.ok(newbooking);
			}
		
			return ResponseEntity.badRequest().build();
			/* message = "already cancelled"; */
		}
		return ResponseEntity.badRequest().build();
		}catch(Exception e){
			return ResponseEntity.badRequest().build();
			}
		
	
		/*else
			message = "booking id is not exist!!";*/

	 }

	



	
	  public String deleteshowbyid(int id) {
	   String message=null;
	 
	 if( srepo.existsById(id)) {
		 srepo.deleteById(id);
		 message="show deleted succesfully";
	 }
	 else {
		 message="id not present";
	 }
	  
		 return message; 
	  
	  }
	

	
	  public void updateshowbyid(Show show) { 
		  Show newshow=new Show(); 
		  Show show1=srepo.findById(show.getShowid()).get();
//		  show1.setMovieId(movieId);
			/* Show show1=srepo.findById(show.getShowid()); */
		/* newshow.setMovieId(); */
	 
	  srepo.save(show);
	 
	  }
	  
	  public List<Show> getShowByMovie(String Moviename){
		  
		  Iterable<Show> shows=srepo.findAll();
		  List<Show> movieshows=new ArrayList();
		  for(Show show:shows) {
			  if(show.getMovieId().getMovieName().equalsIgnoreCase(Moviename)) {
				  movieshows.add(show);
			  }
			  
		  }
		  return movieshows;
	  }
	  
	  
	  public List<Show> getShowByTheatre(String theatrename){
		  Iterable<Show> shows=srepo.findAll();
		
		  List<Show> theatreshows=new ArrayList();
		  for(Show show:shows) {
			  if(show.getTheatreId().getTheatreName().equalsIgnoreCase(theatrename)) {
				  theatreshows.add(show);
				  
			  }
			  
			  
		  }
		  return theatreshows;
	  }
	  
	  
	  
	  public ResponseEntity<List<Booking>> getreport(String fromdate,String enddate) {
		  Iterable<Booking> bookings=brepo.findAll();
		  try {
				/*
				 * Date strtdate1=new SimpleDateFormat("DD-MMM-YYYY").parse(fromdate);
				 * 
				 * Date enddate2=new SimpleDateFormat("DD-MMM-YYYY").parse(enddate);
				 */
			  DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy"); 
				 LocalDate strtdate1 = LocalDate.parse(fromdate, formatter);
				 DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd-MMM-yyyy"); 
				 LocalDate enddate1 = LocalDate.parse(enddate, formatter);
			  List<Booking> filteredlist=new ArrayList();
				/*
				 * DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
				 * LocalDate date1 = LocalDate.parse("27-Sep-2015", formatter);
				 * System.out.println("date string : 27-Sep-2015, " + "localdate : " + date1);
				 */
			
			  for(Booking booking:bookings) {
				  DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MMM-yyyy"); 
					 LocalDate date1 = LocalDate.parse(booking.getShowid().getShowdate(), formatter2); 
					/*
					 * Date showdate=new
					 * SimpleDateFormat("DD-MMM-YYYY").parse(booking.getShowid().getShowdate());
					 * LocalDate date =
					 * showdate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
					 */
						 System.out.println(date1);
				  System.out.println("-----------------");
				  if( date1.isAfter(strtdate1)  && date1.isBefore(enddate1)) {
					  System.out.println("-----------inside if-----------");
					  
					  filteredlist.add(booking);
					  
				  }
				  
			  }
			  return ResponseEntity.ok(filteredlist);
			  
		 
		  }catch(Exception e) {
			  return ResponseEntity.badRequest().build();
		  }
		  }
	 
}
