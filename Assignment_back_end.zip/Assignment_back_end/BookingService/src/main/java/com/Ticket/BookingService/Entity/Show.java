package com.Ticket.BookingService.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="show_table1")
public class Show {
	
	@Id
	private int showid;
	@OneToOne
	@JoinColumn(name="movieid",referencedColumnName="movieId")
	private Movie movieid;
	
	@OneToOne
	@JoinColumn(name="theatreid",referencedColumnName="theatreId")
	private Theatre theatreid;
	private String showtime;
	private String showdate;
	private int rate;
	/* private int requiredseats; */
	private int seatsavailable;
	
	
	
	public int getSeatsavailable() {
		return seatsavailable;
	}
	public void setSeatsavailable(int seatsavailable) {
		this.seatsavailable = seatsavailable;
	}
	
	public int getShowid() {
		return showid;
	}
	public void setShowid(int showid) {
		this.showid = showid;
	}


	public Movie getMovieId() {
		return movieid;
	}
	public void setMovieId(Movie movieId) {
		this.movieid = movieId;
	}
	public Theatre getTheatreId() {
		return theatreid;
	}
	public void setTheatreId(Theatre theatreId) {
		this.theatreid = theatreId;
	}
	public String getShowtime() {
		return showtime;
	}
	public void setShowtime(String showtime) {
		this.showtime = showtime;
	}
	public String getShowdate() {
		return showdate;
	}
	public void setShowdate(String showdate) {
		this.showdate = showdate;
	}
	public int getRate() {
		return rate;
	}
	public void setRate(int rate) {
		this.rate = rate;
	}
	/*
	 * public int getRequiredseats() { return requiredseats; } public void
	 * setRequiredseats(int requiredseats) { this.requiredseats = requiredseats; }
	 */
	
	
	
	

}
