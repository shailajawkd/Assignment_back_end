package com.Ticket.BookingService.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.Ticket.BookingService.Entity.Theatre;

@Repository
public interface TheatreRepository extends CrudRepository<Theatre,Integer> {
	
public Iterable<Theatre> deleteByTheatreName(String theatreName);
	
	public Theatre findByTheatreName(String theatreName);

}
