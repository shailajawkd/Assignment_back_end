import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service';
import { Location } from '@angular/common';
import { User } from '../user';

@Component({
  selector: 'app-adminpage',
  templateUrl: './adminpage.component.html',
  styleUrls: ['./adminpage.component.css']
})
export class AdminpageComponent implements OnInit {
  usern:string;
  user:any;
  upuser:User;
  guser:boolean=false;
  userfun:boolean=true;
  updatefl:boolean=false;
  username:string;
  message:any;

  constructor(private service:UserServiceService,private location: Location) { 
    this.usern=sessionStorage.getItem("userName");
  }

  ngOnInit() {
    let response=this.service.getuserbyname(this.usern);
    response.subscribe(data=>this.user=data);
  }


  public userfunctions(){
    this.guser=false;
    this.userfun=true;
    this.updatefl=false;
  }

  public admindetails(){
    this.guser=true;
    this.userfun=false;
    this.updatefl=false;
  }

  public updateuserbyname(){
    let response=this.service.updateuserbyname(this.user,this.username);
    response.subscribe(data=>{this.upuser=data
    alert("admin details updated successfully")}
    );
  }
  public updateuser(username1){
    this.username=username1;
    this.guser=false;
    this.userfun=false;
    this.updatefl=true;

  }

  // public deactiveaccount(userid){
  //    let response=this.bservice.deactiveuser(userid);
  //    response.subscribe(data=>{this.message=data;
  //    alert("account deleted successfully");
  //    this.route.navigate(['/loginpage']);

  //   },
  //     error=>{this.message="cannot delete your account"}
  //     )

  // }

  public goback(){
    this.location.back();
  }
 

}
