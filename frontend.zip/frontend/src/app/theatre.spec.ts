import { Theatre } from './theatre';

describe('Theatre', () => {
  it('should create an instance', () => {
    expect(new Theatre()).toBeTruthy();
  });
});
