import { Component, OnInit } from '@angular/core';
import { BookingService } from '../booking.service';
import { DatePipe } from '@angular/common';
import { Location } from '@angular/common';
import { Bookingdetails } from '../bookingdetails';
import { Booking } from '../booking';
import { Report } from '../report';


@Component({
  selector: 'app-generatereport',
  templateUrl: './generatereport.component.html',
  styleUrls: ['./generatereport.component.css']
})
export class GeneratereportComponent implements OnInit {

  fromdate:String;
  
  todate:String;
  bookinglist:any;
  searchflag:boolean=true;
  listflag:boolean=false;
  bookingdetails:Bookingdetails;
  bookingdetailslist:Bookingdetails[];
  book:Booking;
  report:Report;

  constructor(private service:BookingService,public datepipe: DatePipe,private location: Location) {
    this.bookingdetails=new Bookingdetails(0,0,"","","","","",0,"");
    this.book=new Booking(0,{userId:0,userName:"",password:"",phoneNumber:"",email:"",role1:{userRole:""}},
    {showid:0,showtime:"",showdate:"",rate:0,seatsavailable:0,movieid:{movieId:0,movieName:"",rating:"",releaseDate:""},theatreid:{theatreId:0,theatreName:"",location:"",seatCapacity:""}}
    ,0,0,"");
    this.report=new Report(0,0,"","","","","",0,0,"");
   }

  ngOnInit(): void {
  }

  public reportgenerate(){
    let newfromdate=this.datepipe.transform(this.fromdate, 'yyyy-MM-dd');
    let newtodate=this.datepipe.transform(this.todate, 'yyyy-MM-dd');
    console.log(this.fromdate)
    console.log(typeof this.fromdate)

   let response=this.service.generatereport(this.fromdate,this.todate);
   response.subscribe(data=>this.bookinglist=data);
   this.listflag=true;
   this.searchflag=false;
  //  for(var book of this.bookinglist){
  //   this.bookingdetails.bookingid=book.bookingid;
  //   this.bookingdetails.moviename=book.showid.movieid.movieName;
  //   this.bookingdetails.amount=book.amount;
  //   this.bookingdetails.seatsbooked=book.seatsbooked;
  //   this.bookingdetails.showdate=book.showid.showdate;
  //   this.bookingdetails.showtime=book.showid.showtime;
  //   this.bookingdetails.theatrename=book.showid.theatreid.threatreName;
  //   this.bookingdetails.username=book.userid.userName;

  //   this.bookingdetailslist.push(this.bookingdetails);


  //  }
  }
 public generatereportflag(){
  this.listflag=false;
  this.searchflag=true;
    
 }


  public goback(){
    this.location.back();
  }

}
