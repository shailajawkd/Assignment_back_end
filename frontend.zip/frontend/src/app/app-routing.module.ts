import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchComponent } from './search/search.component';

import { RegisterComponent } from './register/register.component';
import { CodeforinterviewComponent } from './codeforinterview/codeforinterview.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { UserpageComponent } from './userpage/userpage.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { AllusersComponent } from './allusers/allusers.component';
import { MoviepageComponent } from './moviepage/moviepage.component';
import { TheatrepageComponent } from './theatrepage/theatrepage.component';
import { BookingpageComponent } from './bookingpage/bookingpage.component';
import { AllmoviesComponent } from './allmovies/allmovies.component';
import { AddmovieComponent } from './addmovie/addmovie.component';
import { AddtheatreComponent } from './addtheatre/addtheatre.component';
import { AlltheatresComponent } from './alltheatres/alltheatres.component';
import { ShowpageComponent } from './showpage/showpage.component';
import { AllbookingsComponent } from './allbookings/allbookings.component';
import { AddbookingComponent } from './addbooking/addbooking.component';
import { AllshowsComponent } from './allshows/allshows.component';
import { AddshowComponent } from './addshow/addshow.component';
import { UserAllmoviesComponent } from './user-allmovies/user-allmovies.component';
import { UserAlltheatresComponent } from './user-alltheatres/user-alltheatres.component';
import { UserAllshowsComponent } from './user-allshows/user-allshows.component';
import { GeneratereportComponent } from './generatereport/generatereport.component';
import { UserbookingsComponent } from './userbookings/userbookings.component';
import { HeaderComponent } from './header/header.component';

const routes: Routes = [
  // {
  //  path:"",redirectTo:"codeforinterview",pathMatch:"full" 
  // },
  
  {
    path:"userpage",component:UserpageComponent
  },
  {
  path:"loginpage",component:LoginpageComponent
  },
  {
    path:"search",component:SearchComponent
  },
  {
    path:"register",component:RegisterComponent
  },
  {
    path:"",component:HeaderComponent
  }
  ,
  {
    path:"adminpage",component:AdminpageComponent
  },
  {
    path:"allusers",component:AllusersComponent
  },
  {
    path:"moviepage",component:MoviepageComponent
  }
  ,
  {
    path:"theatrepage",component:TheatrepageComponent
  }
  ,
  {
    path:"bookingpage",component:BookingpageComponent
  }
  ,
  {
    path:"allmovies",component:AllmoviesComponent  
  }
  ,
  {
    path:"addmovie",component:AddmovieComponent  
  }
  ,
  {
    path:"alltheatres",component:AlltheatresComponent  
  }
  ,
  {
    path:"addtheatre",component:AddtheatreComponent  
  }
  ,
  {
    path:"showpage",component:ShowpageComponent  
  }
  ,
  {
    path:"allbookings",component:AllbookingsComponent  
  },
  {
    path:"addbooking",component:AddbookingComponent  
  },
  {
    path:"allshows",component:AllshowsComponent  
  },
  {
    path:"addshow",component:AddshowComponent  
  }
  ,
  {
    path:"user-allmovies",component:UserAllmoviesComponent  
  },
  {
    path:"user-alltheatres",component:UserAlltheatresComponent  
  },
  {
    path:"user-allshows",component:UserAllshowsComponent  
  },
  {
    path:"generatereport",component:GeneratereportComponent  
  }
  ,
  {
    path:"userbookings",component:UserbookingsComponent  
  }

  // {
  //   path:"**", component:CodeforinterviewComponent showpage
  // } generatereport
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
