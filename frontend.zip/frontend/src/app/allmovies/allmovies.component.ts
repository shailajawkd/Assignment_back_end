import { Component, OnInit } from '@angular/core';
import { MovieService } from '../movie.service';
import { Location } from '@angular/common';
import { Movie } from '../movie';
import { BookingService } from '../booking.service';

@Component({
  selector: 'app-allmovies',
  templateUrl: './allmovies.component.html',
  styleUrls: ['./allmovies.component.css']
})
export class AllmoviesComponent implements OnInit {
  message:string;
  movielist:any;
  deleteflag:boolean=true;
  updatefl:boolean=false;
  movieshow:boolean=false;
  movie:Movie;
  mid:number;
  upmovie:Movie;
  movienamelist:any;
  moviename:string;

  constructor(private mservice:MovieService,private bservice:BookingService,private location: Location) { 
   this.upmovie=new Movie(0,"","","");
   this.movie=new Movie(0,"","","");
  }

  ngOnInit(): void {
    let response=this.mservice.getmovies();
    response.subscribe(response=> this.movielist=response)
  }

  public removemovie(moviename:String){
    let response=this.mservice.deletemoviebyname(moviename);
    response.subscribe(response=>{ this.movielist=response
      this.deleteflag=true;
      this.updatefl=false;
      this.movieshow=false;
    },
      // alert("movie deleted successfully, please refresh the page")},
      error=>{
        this.message="Show is available for the movie, it cann't delete"
      }
      );

  }

  public updateflag(movi){
    this.deleteflag=false;
    this.updatefl=true;
    this.movieshow=false;
    this.mid=movi.movieId;
    this.movie.movieId=movi.movieId;
    this.movie.movieName=movi.movieName;
    this.movie.rating=movi.rating;
    this.movie.releaseDate=movi.releaseDate;

  }

  public updatemovie(){
    let response=this.mservice.updatemovie(this.movie,this.mid);
    response.subscribe(data=>{this.upmovie=data
      alert("movie updated successfully")
    });
  }
 
  public allmovie(){
    this.deleteflag=true;
    this.updatefl=false;
    this.movieshow=false;
    
  }

  public getmoviebyname(){
    let response=this.mservice.getmoviebyname(this.moviename);
    response.subscribe(data=>this.movienamelist=data
    
      
      );
    this.deleteflag=false;
    this.movieshow=true;
    // this.theatreshow=false;
    this.updatefl=false;

  }


  public goback(){
    this.location.back();
  }

}
