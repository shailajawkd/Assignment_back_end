import { Component, OnInit } from '@angular/core';
import { Addshow } from '../addshow';
import { DatePipe, getLocaleDateTimeFormat } from '@angular/common';
import { ShowService } from '../show.service';
import { ShowTable1 } from '../show-table1';
import { Location } from '@angular/common';
import { TheatreService } from '../theatre.service';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-addshow',
  templateUrl: './addshow.component.html',
  styleUrls: ['./addshow.component.css']
})
export class AddshowComponent implements OnInit {
  addshow:Addshow;
  show:ShowTable1;
  message:string;
  allmovies:any;
  alltheatres:any;

  constructor(private tservice:TheatreService,private mservice:MovieService,private service:ShowService,private location: Location,private datepipe: DatePipe) { 
    this.addshow=new Addshow("","","","",0,0)  
  }

  ngOnInit(): void {
    let response=this.mservice.getmovies();
    response.subscribe(data=>this.allmovies=data)

    let response1=this.tservice.gettheatres();
    response1.subscribe(data=>this.alltheatres=data)



  }

  public addnewshow(){
    // let newfromdate=this.datepipe.transform(this.addshow.showdate, 'dd-MM-yyyy');
    // let newfromtime=this.datepipe.transform(this.addshow.showtime, 'hh:mm');
    
    console.log(this.addshow.showdate);
    console.log(typeof this.addshow.showdate);
    console.log(this.addshow.showtime);
    console.log(this.addshow.moviename);
    console.log(this.addshow.theatrename);
    console.log(typeof this.addshow.showtime);
    let response=this.service.addshow(this.addshow);
    response.subscribe(data=>{
      this.show=data;
      this.message="Show added successfully!!"
    alert("Show added successfully!!")
    },
    error=>{console.log("exception occured");
    this.message="please enter valid show date,time and availableseats";
 
    }
    
    )

  }
  public goback(){
    this.location.back();
  }

}
