import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MovieService {

  constructor(private http:HttpClient) { }

  public getmovies(){
    return this.http.get("http://localhost:8888/movie-service/AllMovies");

  }
  public removemovie(moviename:String){
    return this.http.get("http://localhost:8888/movie-service/delete/"+moviename)
  }

  public addmovie(movie):Observable<any>{
    return this.http.post<any>("http://localhost:8888/movie-service/addmovie",movie,{responseType:"text" as "json"})

  }
  public updatemovie(movie,movieid):Observable<any>{
    return this.http.put<any>("http://localhost:8888/movie-service/movie/"+movieid,movie,{responseType:"text" as "json"});
  }

  public getmoviebyid(movieid){
    return this.http.get("http://localhost:8888/movie-service/getmovie1/"+movieid);
  }

  public getmoviebyname(moviename){
    return this.http.get("http://localhost:8888/movie-service/getmovie/"+moviename);
  }

  public deletemoviebyname(moviename){
    return this.http.get("http://localhost:8888/booking-service/deletemovie/"+moviename);
  }


}
