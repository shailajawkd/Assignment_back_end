import { Movie } from './movie';
import { Theatre } from './theatre';

export class ShowTable1 {

 public constructor(
    public showid:number,
    public showtime:string,
    public showdate:string,
    public rate:number,
    public seatsavailable:number,
    public movieid:Movie,
    public theatreid:Theatre

 ){
     

 }


}
