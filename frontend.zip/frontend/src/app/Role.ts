export class  Role{
    public  constructor(

      public userRole:string
      ){}
   
}