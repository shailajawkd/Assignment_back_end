import { Component, OnInit } from '@angular/core';
import { BookingService } from '../booking.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-userbookings',
  templateUrl: './userbookings.component.html',
  styleUrls: ['./userbookings.component.css']
})
export class UserbookingsComponent implements OnInit {
  Cancel:string="Cancel";
  username:string;
  bookingdetails:any;
  bookingdetailslist:any

  constructor(private bservice:BookingService,private location: Location) { 
    this.username=sessionStorage.getItem("userName");}

  ngOnInit(): void {
    console.log(this.username);
    let response=this.bservice.getbookingbyuser(this.username);
    response.subscribe(data=>this.bookingdetails=data);

  }
  public cancelbooking(booking){
    if(booking.bookingstatus!="cancelled"){
    let response=this.bservice.cancelbooking(booking.bookingid);
    response.subscribe(data=>{this.bookingdetailslist=data
     alert("booking cancelled successfully")
    })
  }else{
  

    alert("booking already cancelled");
  }

  }

  public goback(){
    this.location.back();
  }

}
