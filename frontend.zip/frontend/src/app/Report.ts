export class Report {
      public constructor(
        public bookingid:number,
        public showid:number,
        public username:string,
        public moviename:string,
        public theatrename:string,
        public showdate:string,
        public showtime:string,
        public seatsbooked:number,
        public amount:number,
        public bookingstatus:string

      ){}
      }
