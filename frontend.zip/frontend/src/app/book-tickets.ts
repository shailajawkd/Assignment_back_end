export class BookTickets {
    public constructor(
        public username:string,
        public moviename:string,
        public theatrename:string,
        public showtime:string,
        public showdate:string,
        public seatsBooked:number

    ){}
}
