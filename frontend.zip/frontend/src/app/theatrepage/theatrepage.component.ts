import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theatrepage',
  templateUrl: './theatrepage.component.html',
  styleUrls: ['./theatrepage.component.css']
})
export class TheatrepageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
