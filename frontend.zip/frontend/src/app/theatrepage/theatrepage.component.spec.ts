import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TheatrepageComponent } from './theatrepage.component';

describe('TheatrepageComponent', () => {
  let component: TheatrepageComponent;
  let fixture: ComponentFixture<TheatrepageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TheatrepageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TheatrepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
