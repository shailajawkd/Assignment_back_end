import { User } from './user';
import { ShowTable1 } from './show-table1';

export class Booking {

    public constructor(
        public bookingid:number,
        public userid:User,
        public showid:ShowTable1,
        public seatsbooked:number,
        public amount:number,
        public bookingstatus:string

    ){
        
    }

    
}
