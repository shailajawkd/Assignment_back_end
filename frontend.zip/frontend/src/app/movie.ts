export class Movie {
    public constructor(
        public movieId:number,
        public movieName:String,
        public rating:String,
        public releaseDate:String
    ){}
}
