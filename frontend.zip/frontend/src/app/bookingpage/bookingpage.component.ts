import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingpage',
  templateUrl: './bookingpage.component.html',
  styleUrls: ['./bookingpage.component.css']
})
export class BookingpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
