import { Component, OnInit } from '@angular/core';
import { ShowService } from '../show.service';
import { Location } from '@angular/common';
import {Showdetails} from '../showdetails'
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-allshows',
  templateUrl: './allshows.component.html',
  styleUrls: ['./allshows.component.css']
})
export class AllshowsComponent implements OnInit {
  showdetails:any;
  deleteflag:boolean=true;
  updatefl:boolean=false;
  addshow:Showdetails;
  sid:number;
  upshow:Showdetails;
  moviename:string="";
  theatrename:string="";
  movieshowslist:any;
  theatreshowslist:any;
  movieshow:boolean=false;
  theatreshow:boolean=false;
  removemessage:any;
  movielist:any;

  constructor(private service:ShowService,private mservice:MovieService,private location: Location) {
    this.addshow=new Showdetails(0,"","","","",0,0);
    this.upshow=new Showdetails(0,"","","","",0,0);
   }

  ngOnInit(): void {
    let response=this.service.getshows();
    response.subscribe(data=>this.showdetails=data);

    let response1=this.mservice.getmovies();
    response.subscribe(response=> this.movielist=response)


  }
  public theatreremoveshow(showid){
    let response=this.service.removeshow(showid);
    response.subscribe(data=>this.theatreshowslist=data)
  }

  public movieremoveshow(showid){
    let response=this.service.removeshow(showid);
    response.subscribe(data=>this.movieshowslist=data)
  }


  public removeshow(showid){
    let response=this.service.removeshow(showid);
    response.subscribe(data=>{this.showdetails=data},
      error=>this.removemessage="bookings are available for the show, Cann't delete it")
  }

  public allshows(){
    this.deleteflag=true;
    this.movieshow=false;
    this.theatreshow=false;
    this.updatefl=false;

  }


  public getshowsbymovie(){
    console.log(this.movielist.includes(this.moviename) );
    if(this.moviename in this.movielist){
      let response=this.service.showsbymovie(this.moviename);
      response.subscribe(data=>this.movieshowslist=data);
      this.deleteflag=false;
      this.movieshow=true;
      this.theatreshow=false;
      this.updatefl=false;
     
    }
    // let response=this.service.showsbymovie(this.moviename);
    // response.subscribe(data=>this.movieshowslist=data);
    // this.deleteflag=false;
    // this.movieshow=true;
    // this.theatreshow=false;
    // this.updatefl=false;
   

  }

  public getshowsbytheatre(){
    let response=this.service.showsbytheatre(this.theatrename);
    response.subscribe(data=>this.theatreshowslist=data)
    this.deleteflag=false;
    this.movieshow=false;
    this.theatreshow=true;
    this.updatefl=false;
  
  
  }



  public updateflag(newshow){
    this.deleteflag=false;
  this.updatefl=true;
  this.movieshow=false;
  this.theatreshow=false;
  this.sid=newshow.showid;
  this.addshow.showid=newshow.showid;
  this.addshow.moviename=newshow.moviename;
  this.addshow.theatrename=newshow.theatrename;
  this.addshow.rate=newshow.rate;
  this.addshow.seatsavailable=newshow.seatsavailable;
  this.addshow.showdate=newshow.showdate;
  this.addshow.showtime=newshow.showtime;


  }

  public updateshow(){
    let response=this.service.updateshow(this.addshow,this.sid);
    response.subscribe(data=>{this.upshow=data;
      alert("Show updated successfully");
    },
    error=>{
      alert("please enter valid show date,time and availableseats");

    }
    
    );
    
  }


  public goback(){
    this.location.back();
  }

}
