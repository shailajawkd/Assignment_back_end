import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service';
import { User } from '../user';
import { Location } from '@angular/common';

@Component({
  selector: 'app-allusers',
  templateUrl: './allusers.component.html',
  styleUrls: ['./allusers.component.css']
})
export class AllusersComponent implements OnInit {

  userlist:any;
  username:string;

  constructor(private service:UserServiceService,private location: Location) { }

  ngOnInit() {
    let response= this.service.getUsers();
    response.subscribe((response)=> this.userlist=response)
  }
  public removeuser(username:string){
   let response=this.service.removeuser(username);
   response.subscribe(data=> this.userlist=data)
  
   }
   public goback(){
    this.location.back();
  }

}
