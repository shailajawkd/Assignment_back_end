import { Component, OnInit } from '@angular/core';
import { Theatre } from '../theatre';
import { TheatreService } from '../theatre.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-addtheatre',
  templateUrl: './addtheatre.component.html',
  styleUrls: ['./addtheatre.component.css']
})
export class AddtheatreComponent implements OnInit {
  theatre:Theatre;
  newtheatre:any;
  message:string;

  constructor(private tservice:TheatreService,private location: Location) {
    this.theatre=new Theatre(0,"","","")
   }

  ngOnInit(): void {
  }

  public addTheatre(){
    let response=this.tservice.addtheatre(this.theatre);
    response.subscribe(data=>{this.newtheatre=data
      alert("theatre added successfully")
      this.message="theatre added successfully"
    },error=>{
      this.message="please enter valid theatrename and seatcapacity"

    }
      
      )

  }
  public goback(){
    this.location.back();
  }

}
