export class Theatre {
    public constructor(
        public theatreId:number,
        public theatreName:String,
        public location:String,
        public seatCapacity:String
    ){}
}
