export class Addshow {
    public constructor(
        public moviename:string,
        public theatrename:string,
        public showdate:string,
        public showtime:string,
        public rate:number,
        public seatsavailable:number

    ){

    }
}
