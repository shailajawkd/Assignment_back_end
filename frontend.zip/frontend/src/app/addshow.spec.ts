import { Addshow } from './addshow';

describe('Addshow', () => {
  it('should create an instance', () => {
    expect(new Addshow()).toBeTruthy();
  });
});
