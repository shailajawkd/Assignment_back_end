import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAllshowsComponent } from './user-allshows.component';

describe('UserAllshowsComponent', () => {
  let component: UserAllshowsComponent;
  let fixture: ComponentFixture<UserAllshowsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserAllshowsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserAllshowsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
