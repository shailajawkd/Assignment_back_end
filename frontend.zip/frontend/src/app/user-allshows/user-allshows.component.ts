import { Component, OnInit } from '@angular/core';
import { ShowService } from '../show.service';
import { Location } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-allshows',
  templateUrl: './user-allshows.component.html',
  styleUrls: ['./user-allshows.component.css']
})
export class UserAllshowsComponent implements OnInit {
  showdetails:any;
  moviename:string="";
  theatrename:string="";
  movieshowslist:any;
  theatreshowslist:any;
  Allshow:boolean=true;
  movieshow:boolean=false;
  theatreshow:boolean=false;

  constructor(private service:ShowService,private location: Location,private route:Router) { }

  ngOnInit(): void {
    let response=this.service.getshows();
    response.subscribe(data=>this.showdetails=data)
  }

  public goback(){
    this.location.back();
  }

  public getshowsbymovie(){
    let response=this.service.showsbymovie(this.moviename);
    response.subscribe(data=>this.movieshowslist=data);
    this.Allshow=false;
    this.movieshow=true;
    this.theatreshow=false

  }

  public allshows(){
    this.Allshow=true;
    this.movieshow=false;
    this.theatreshow=false


  }

  public getshowsbytheatre(){
    let response=this.service.showsbytheatre(this.theatrename);
    response.subscribe(data=>this.theatreshowslist=data)
    this.Allshow=false;
    this.movieshow=false;
    this.theatreshow=true


  }

  public booking(showid){
    sessionStorage.setItem("showId",showid);

    this.route.navigate(['/addbooking']);


  }

}
