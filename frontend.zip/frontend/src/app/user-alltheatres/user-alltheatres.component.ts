import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { TheatreService } from '../theatre.service';

@Component({
  selector: 'app-user-alltheatres',
  templateUrl: './user-alltheatres.component.html',
  styleUrls: ['./user-alltheatres.component.css']
})
export class UserAlltheatresComponent implements OnInit {
  theatrelist:any;
  allflag:boolean=true;
  theatreflag:boolean=false;
  theatrename:string;
  theatre:any

  constructor(private tservice:TheatreService,private location: Location) { }

  ngOnInit() {
    let response=this.tservice.gettheatres();
    response.subscribe(data=>this.theatrelist=data)
  }

 public alltheatrea(){
     this.allflag=true;
     this.theatreflag=false;
  }

  public goback(){
    this.location.back();
  }

  public gettheatrebyname(){
    let response=this.tservice.gettheatreByname(this.theatrename);
    response.subscribe(data=>this.theatre=data)
    this.allflag=false;
     this.theatreflag=true;
  }

}
