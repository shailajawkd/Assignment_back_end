import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAlltheatresComponent } from './user-alltheatres.component';

describe('UserAlltheatresComponent', () => {
  let component: UserAlltheatresComponent;
  let fixture: ComponentFixture<UserAlltheatresComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserAlltheatresComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserAlltheatresComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
