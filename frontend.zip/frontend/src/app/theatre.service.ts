import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TheatreService {

  constructor(private http:HttpClient) { }

  public gettheatres(){
    return this.http.get("http://localhost:8888/theatre-service/alltheatres");
  }

  public removetheatre(theatrename){
    return this.http.get("http://localhost:8888/theatre-service/delete/"+theatrename);

  }

  public addtheatre(theatre):Observable<any>{
    return this.http.post<any>("http://localhost:8888/theatre-service/addtheatre",theatre,{responseType:"text" as "json"})
  }

  public updatetheatre(theatre,theatreid):Observable<any>{
    return this.http.put<any>("http://localhost:8888/theatre-service/theatre/"+theatreid,theatre,{responseType:"text" as "json"});
  }

  public gettheatreByid(theatreid){
    return this.http.get("http://localhost:8888/theatre-service/getthea/"+theatreid)

  }

  public gettheatreByname(theatrename){
    return this.http.get("http://localhost:8888/theatre-service/gettheatre/"+theatrename)

  }
public deletetheatrebyname(theatrename){
  return this.http.get("http://localhost:8888/booking-service/deletetheatre/"+theatrename)
}

}
