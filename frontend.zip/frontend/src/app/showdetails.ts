export class Showdetails {
    public constructor(
        public showid:number,
        public moviename:string,
        public theatrename:string,
        public showdate:string,
        public showtime:string,
        public rate:number,
        public seatsavailable:number

    ){

    }
}
