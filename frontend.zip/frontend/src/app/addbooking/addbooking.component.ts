import { Component, OnInit } from '@angular/core';
import { BookTickets } from '../book-tickets';
import { BookingService } from '../booking.service';
import { ShowService } from '../show.service';
import { Booking } from '../booking';
import { Location } from '@angular/common';

import { ShowTable1 } from '../show-table1';


@Component({
  selector: 'app-addbooking',
  templateUrl: './addbooking.component.html',
  styleUrls: ['./addbooking.component.css']
})
export class AddbookingComponent implements OnInit {
  bookticket:BookTickets;
  booking:Booking;
  message:string;
  newmessage:string;
  shoid:number;
  getshow:any;
  // username:string;
  moviename:string;
  theatrename:string;
  showtime:string;
  showdate:string;
  seatsavailable:number;
  seatspage:boolean=true;
  bookpage:boolean=false;
  ticket:boolean=false;

  constructor(private bservice:BookingService,private service:ShowService,private location: Location) { 
    this.bookticket=new BookTickets("","","","","",0);
    var showid=sessionStorage.getItem("showId");
var username=sessionStorage.getItem("userName");
this.bookticket.username= username;
    this.shoid= +showid;
    console.log(this.shoid);
    console.log(typeof this.shoid);
   
  
  }

  ngOnInit(): void {
    
    var showid=sessionStorage.getItem("showId");
    this.shoid= +showid;
    let response=this.service.getshowbyid(this.shoid);
    response.subscribe(data=>{
      this.getshow=data;
    this.moviename=this.getshow.moviename;
    this.theatrename=this.getshow.theatrename;
    this.showdate=this.getshow.showdate;
    this.showtime=this.getshow.showtime;
  
    this.bookticket.moviename=this.moviename;
    this.bookticket.theatrename=this.theatrename;
    this.bookticket.showdate=this.showdate;
    this.bookticket.showtime=this.showtime;
    this.seatsavailable=this.getshow.seatsavailable;
    
  });

  }
  public addbooking(){
    let response=this.bservice.addbooking(this.bookticket);
    response.subscribe((data)=>{
      this.booking=data;
      this.message="booking successfull";
      this.seatspage=false;
      this.ticket=true;
      this.bookpage=false;
     
    // alert("booking successfull");
      
   
    },error=>{console.log("exception occured");
    this.message="sorry your request not processed,show is not available!!";
 
    }

    
    );


  }
public seatapage(){
  this.seatspage=true;
  this.bookpage=false;
  this.ticket=false
}

  public Book(){
    this.seatspage=false;
  this.bookpage=true;
  this.ticket=false
  }

  // public getshowbyid(){
  //   let response=this.service.showbyid(this.shoid);
  //   response.subscribe(data=>{this.show=data
  //   this.moviename=this.show.movieid.moviename;
  //   this.theatrename=this.show.theatreid.theatrename;
  //   this.showdate=this.show.showdate;
  //   this.showtime=this.show.showtime;
  //   this.bookticket.moviename=this.moviename;
  //   this.bookticket.theatrename=this.theatrename;
  //   this.bookticket.showdate=this.showdate;
  //   this.bookticket.showtime=this.showtime;
    
  //   });

  // }

  public goback(){
    this.location.back();
  }

}
