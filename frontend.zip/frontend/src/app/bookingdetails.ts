export class Bookingdetails {
    public constructor(
        public bookingid:number,
        public seatsbooked:number,
        public showdate:string,
        public showtime:string,
        public username:string,
        public moviename:string,
        public theatrename:string,
        public amount:number,
        public bookingstatus:string
        
    ){}
}
