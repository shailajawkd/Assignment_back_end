import { Role } from './Role';

export class  User{
 public constructor(
      public userId:number,
      public userName:string,
      public password:string,
       public phoneNumber:string,
        public email:string,
        public role1:Role,
  ){}
}