import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  constructor(private http:HttpClient) { }

  public getBookings(){
    return this.http.get("http://localhost:8888/booking-service/allbookings");
  }
  public cancelbooking(bookingid:number){
    return this.http.get("http://localhost:8888/booking-service/deletebooking/"+bookingid);

  }
  public addbooking(bookticket):Observable<any>{
    return this.http.post<any>("http://localhost:8888/booking-service/booking",bookticket,{responseType:"text" as "json"})

  }

  public generatereport(fromdate,todate){
    return this.http.get("http://localhost:8888/booking-service/getreport/"+fromdate+"/"+todate);
  }
public getbookingbyuser(username){
  return this.http.get("http://localhost:8888/booking-service/getbooking/"+username)
}

public deactiveuser(userid){
  return this.http.get("http://localhost:8888/booking-service/deleteuser/"+userid)
}

}
