import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { LoginpageComponent } from '../loginpage/loginpage.component';
import { UserServiceService } from '../user-service.service';
import { Location } from '@angular/common';
import { BookingService } from '../booking.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userpage',
  templateUrl: './userpage.component.html',
  styleUrls: ['./userpage.component.css']
})
export class UserpageComponent implements OnInit {
  usern:string;
  user:any;
  upuser:User;
  guser:boolean=false;
  userfun:boolean=true;
  updatefl:boolean=false;
  username:string;
  message:any;

  // users:User=new User(0,"","","","",{userRole:""});

  constructor(private service:UserServiceService,private bservice:BookingService,private location: Location,private route:Router) {
    this.user=new User(0,"","","","",{userRole:""});
   this.usern=sessionStorage.getItem("userName");

   }

  ngOnInit(): void {
    // this.usern=sessionStorage.getItem("userName");
    let response=this.service.getuserbyname(this.usern);
    response.subscribe(data=>this.user=data);
  
 
    // console.log(this.users.userName);
   
  } 
  public userfunctions(){
    this.guser=false;
    this.userfun=true;
    this.updatefl=false;
  }

  public userdetails(){
    this.guser=true;
    this.userfun=false;
    this.updatefl=false;
  }

  public updateuserbyname(){
    let response=this.service.updateuserbyname(this.user,this.username);
    response.subscribe(data=>{this.upuser=data
    alert("user values updated successfully")}
    );
  }
  public updateuser(username1){
    this.username=username1;
    this.guser=false;
    this.userfun=false;
    this.updatefl=true;

  }

  public deactiveaccount(userid){
    // let action
     let response=this.bservice.deactiveuser(userid);
     response.subscribe(data=>{this.message=data;
     alert("account deleted successfully");
     this.route.navigate(['/loginpage']);

    },
      error=>{this.message="cannot delete your account"}
      )

  }

  public goback(){
    this.location.back();
  }
 



}
