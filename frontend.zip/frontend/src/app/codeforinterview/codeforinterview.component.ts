import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-codeforinterview',
  templateUrl: './codeforinterview.component.html',
  styleUrls: ['./codeforinterview.component.css']
})
export class CodeforinterviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
