import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service';
import { userlogin } from '../userlogin';
import { Router } from '@angular/router';
import { User } from '../user';
import { NgForm} from '@angular/forms'
import { Role } from '../Role';
import { Location } from '@angular/common';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})

export class LoginpageComponent implements OnInit {
  users: any;
  login: boolean = true;
  userpage: boolean = false;
  ulogin: userlogin;
  message: String;
  urole:String;
  user:User;
  role:Role;
  userr:User;
  userName1="";
  constructor(private service: UserServiceService,private _route:Router,private location: Location) { 
    this.user=new User(0,"","","","",{"userRole":""});
    this.role=new Role("");
  }

  ngOnInit() {
    let response = this.service.getUsers();
    response.subscribe(data => this.users = data)

    // this.service.currentMessage.subscribe(message => this.userr = message)
  }
  // public completelogin(){
  //   this.login=false;
  // }

  // public loginpage(uname1: string, pword1: string) {
  //   console.log(uname1);
  //   this.ulogin = new userlogin();
  //   this.ulogin.username = uname1;
  //   this.ulogin.password = pword1;
  //   console.log(this.ulogin);
  //   let response = this.service.userloginpage(this.ulogin);
  //   response.subscribe(data => this.message = data);
  //   alert(this.message);
  //   console.log(this.message);
  //   console.log(this.message == 'Login is successfull!!');
  //  if (this.message == "Login is successfull!!") {
  //      this.login = this.login ? false : true;
  //    this.userpage = this.userpage ? false : true;

  //    }

  // }
  public loginuser(){
    // console.log(this.user.userName)
   let response=this.service.loginUserFromRemote(this.user);
   response.subscribe(
     (response)=>
    {
    
      this.user=response
      // this.urole=response.role1.userRole;
      console.log(response.role);

      console.log(this.user.userName);
    this.userr=this.user;
    console.log(this.userr);
    this.role=this.userr.role1;
    console.log(this.userr.role1);
    console.log(this.role);
    this.urole=this.role.userRole;
    sessionStorage.setItem("userName",response.userName);
     if(this.urole=="admin"){
    this._route.navigate(['/adminpage']);
    }
   else{
     this._route.navigate(['/userpage']);

     }
  },
   error=>{console.log("exception occured");
   this.message="Bad Credentials, please enter valid username nad password";
  }
  
   );

   }
   public goback(){
    this.location.back();
  }

}
