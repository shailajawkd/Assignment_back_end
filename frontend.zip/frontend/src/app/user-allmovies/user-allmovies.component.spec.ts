import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAllmoviesComponent } from './user-allmovies.component';

describe('UserAllmoviesComponent', () => {
  let component: UserAllmoviesComponent;
  let fixture: ComponentFixture<UserAllmoviesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserAllmoviesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserAllmoviesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
