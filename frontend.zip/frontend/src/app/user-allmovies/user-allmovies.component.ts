import { Component, OnInit } from '@angular/core';
import { MovieService } from '../movie.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-user-allmovies',
  templateUrl: './user-allmovies.component.html',
  styleUrls: ['./user-allmovies.component.css']
})
export class UserAllmoviesComponent implements OnInit {
  movielist:any;
  moviename:string;
  movie:any;
  allflag:boolean=true;
  movieflag:boolean=false;

  constructor(private mservice:MovieService,private location: Location) { }

  ngOnInit(): void {
    let response=this.mservice.getmovies();
    response.subscribe(response=> this.movielist=response)

  }

  public allmovies(){
    this.allflag=true;
    this.movieflag=false;
  }

  public getmoviebyname(){
    let response=this.mservice.getmoviebyname(this.moviename);
    response.subscribe(data=>this.movie=data);
    this.allflag=false;
    this.movieflag=true;
  }


  public goback(){
    this.location.back();
  }

}
