import { Component, OnInit } from '@angular/core';
import { BookingService } from '../booking.service';

import { Location } from '@angular/common';

@Component({
  selector: 'app-allbookings',
  templateUrl: './allbookings.component.html',
  styleUrls: ['./allbookings.component.css']
})
export class AllbookingsComponent implements OnInit {
  bookingdetail:any;
  constructor(private bservice:BookingService,private location: Location) { }

  ngOnInit(): void {
    let response=this.bservice.getBookings();
    response.subscribe(data=>this.bookingdetail=data)
  }

  public cancelbooking(bookingid:number){
    let response=this.bservice.cancelbooking(bookingid);
    response.subscribe(data=>this.bookingdetail=data)

  }
  public goback(){
    this.location.back();
  }


}
