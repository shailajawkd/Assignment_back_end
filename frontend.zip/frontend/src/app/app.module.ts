import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { SearchComponent } from './search/search.component';
import { FooterComponent } from './footer/footer.component';

import { RegisterComponent } from './register/register.component';
import { CodeforinterviewComponent } from './codeforinterview/codeforinterview.component';

import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { UserServiceService } from './user-service.service';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { UserpageComponent } from './userpage/userpage.component';
import { TheatreService } from './theatre.service';
import { MovieService } from './movie.service';
import {BookingService} from './booking.service';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { AllusersComponent } from './allusers/allusers.component';
import { MoviepageComponent } from './moviepage/moviepage.component';
import { TheatrepageComponent } from './theatrepage/theatrepage.component';
import { BookingpageComponent } from './bookingpage/bookingpage.component';
import { AllmoviesComponent } from './allmovies/allmovies.component';
import { AddmovieComponent } from './addmovie/addmovie.component';
import { AddtheatreComponent } from './addtheatre/addtheatre.component';
import { AddshowComponent } from './addshow/addshow.component';
import { AlltheatresComponent } from './alltheatres/alltheatres.component';
import { AllshowsComponent } from './allshows/allshows.component';
import { AllbookingsComponent } from './allbookings/allbookings.component';
import { ShowpageComponent } from './showpage/showpage.component';
import { AddbookingComponent } from './addbooking/addbooking.component';
import { ShowService } from './show.service';
import { UserAllmoviesComponent } from './user-allmovies/user-allmovies.component';
import { UserAlltheatresComponent } from './user-alltheatres/user-alltheatres.component';
import { UserAllshowsComponent } from './user-allshows/user-allshows.component';
import { GeneratereportComponent } from './generatereport/generatereport.component';
import { DatePipe } from '@angular/common';
import { UserbookingsComponent } from './userbookings/userbookings.component';
 
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SearchComponent,
    FooterComponent,
    
    RegisterComponent,
    CodeforinterviewComponent,
    LoginpageComponent,
    UserpageComponent,
    AdminpageComponent,
    AllusersComponent,
    MoviepageComponent,
    TheatrepageComponent,
    BookingpageComponent,
    AllmoviesComponent,
    AddmovieComponent,
    AddtheatreComponent,
    AddshowComponent,
    AlltheatresComponent,
    AllshowsComponent,
    AllbookingsComponent,
    ShowpageComponent,
    AddbookingComponent,
    UserAllmoviesComponent,
    UserAlltheatresComponent,
    UserAllshowsComponent,
    GeneratereportComponent,
    UserbookingsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [UserServiceService,
    TheatreService,
    MovieService,
    BookingService,
    ShowService,
    DatePipe
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
