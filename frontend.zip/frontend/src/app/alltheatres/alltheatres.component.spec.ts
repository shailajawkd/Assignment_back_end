import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AlltheatresComponent } from './alltheatres.component';

describe('AlltheatresComponent', () => {
  let component: AlltheatresComponent;
  let fixture: ComponentFixture<AlltheatresComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AlltheatresComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AlltheatresComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
