import { Component, OnInit } from '@angular/core';
import { TheatreService } from '../theatre.service';
import { Location } from '@angular/common';
import { Theatre } from '../theatre';

@Component({
  selector: 'app-alltheatres',
  templateUrl: './alltheatres.component.html',
  styleUrls: ['./alltheatres.component.css']
})
export class AlltheatresComponent implements OnInit {
  theatrelist:any;
  deleteflag:boolean=true;
  updatefl:boolean=false;
  theatreshow:boolean=false;
  theatre:Theatre;
  tid:number;
  uptheatre:Theatre;
  theatrename:string;
  theatreshowslist:any
  message:string;


  constructor(private tservice:TheatreService,private location: Location) {
    this.theatre=new Theatre(0,"","","");
    this.uptheatre=new Theatre(0,"","","");
   }

  ngOnInit() {
    let response=this.tservice.gettheatres();
    response.subscribe(data=>this.theatrelist=data)
  }

  public removetheatre(theatrename){
    let response=this.tservice.deletetheatrebyname(theatrename);
    response.subscribe(data=>{this.theatrelist=data
      this.deleteflag=true;
      this.updatefl=false;
      this.theatreshow=false;
    },

      error=>{
        this.message="show is available for the theatre, cann't delete it"
      }
      
      
      );

  }
 public updateflag(thea){
  this.deleteflag=false;
  this.updatefl=true;
  this.theatreshow=false;
  this.tid=thea.theatreId;
  this.theatre.theatreId=thea.theatreId;
  this.theatre.theatreName=thea.theatreName;
  this.theatre.location=thea.location;
  this.theatre.seatCapacity=thea.seatCapacity;
  


 }

 public updatetheatre(){
   let response=this.tservice.updatetheatre(this.theatre,this.tid);
   response.subscribe(data=>{this.uptheatre=data;
   alert("Theatre updated successfully");
   },
   error=>{
     alert("theatre capacity should be greater than 0")
   })
   
 }

 public alltheatres(){
  this.deleteflag=true;
  this.updatefl=false;
  this.theatreshow=false;
}
public gettheatrebyname(){
  let response=this.tservice.gettheatreByname(this.theatrename)
  response.subscribe(data=>this.theatreshowslist=data)
  this.deleteflag=false;
  this.updatefl=false;
  this.theatreshow=true;
}


  public goback(){
    this.location.back();
  }

}
