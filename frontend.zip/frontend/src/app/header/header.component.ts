import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  loginflag:boolean=true;
  loginsuccess:boolean=false;

  constructor( private route:Router) { }

  ngOnInit(): void {
  }

  public login(){
  //  this.loginflag=false;
    // this.loginsuccess=true;
    this.route.navigate(['/loginpage']);

  }

}
