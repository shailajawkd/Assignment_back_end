import { Component, OnInit } from '@angular/core';
import {UserServiceService} from '../user-service.service'
import {User} from  '../user'
import { Router } from '@angular/router';
import { Location } from '@angular/common';
// import { FormBuilder, Validators, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

//  loginForm:any;
// loginForm: FormGroup;
  registration:boolean=true;
  login:boolean=false;
   message:any;
   user:User;
  constructor(private service:UserServiceService,private _route:Router ,private location: Location) { 
    this.user=new User(0,"","","","",{"userRole":"user"});
   
  }

  ngOnInit(){
    // this.loginForm  =  this.formBuilder.group({
    //   email: ['', Validators.required],
    //    password: ['', Validators.required]
    //   });
  }
  public registerNow(){
   let response=this.service.doregistration(this.user)
   response.subscribe(
     data=> {console.log("response recieved");
    this._route.navigate(['/loginpage'])
    alert("registration successfull!!")
  },
   error=>{console.log("exception occured");
   this.message="Bad Credentials, please enter valid username nad password";

   });
  
   this.registration=false;
   this.login=true;
  }
  // public loginuser(){
  //   console.log(this.user.userName)
  //  let response=this.service.loginUserFromRemote(this.user);
  //  response.subscribe(data=>
  //   {console.log("response recieved");
  //   this._route.navigate(['/loginsuccess'])
  // },
  //  error=>{console.log("exception occured");
  //  this.message="Bad Credentials, please enter valid emailid nad password";
  // }
  //  );

  //  }

  public goback(){
    this.location.back();
  }

  
}
