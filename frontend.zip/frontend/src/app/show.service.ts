import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShowService {

  constructor(private http:HttpClient) { }

  public getshows(){
    return this.http.get("http://localhost:8888/booking-service/allshows");
  }
  public removeshow(showid){
    return this.http.get("http://localhost:8888/booking-service/deleteshow/"+showid);

  }
  public addshow(addshow):Observable<any>{
    return this.http.post<any>("http://localhost:8888/booking-service/addshow",addshow,{responseType:"text" as "json"});

  }

  public updateshow(show,showid):Observable<any>{
    return this.http.put<any>("http://localhost:8888/booking-service/updateshow/"+showid,show,{responseType:"text" as "json"});

  }

  public showbyid(showid){
    return this.http.get("http://localhost:8888/booking-service/getshow/"+showid);
  }

 public showsbymovie(moviename){
 return this.http.get("http://localhost:8888/booking-service/getshowbymovie/"+moviename);
 }

 public showsbytheatre(theatrename){
  return this.http.get("http://localhost:8888/booking-service/getshowbytheatre/"+theatrename);
  }

  public getshowbyid(showid){
    return this.http.get("http://localhost:8888/booking-service/getdisplyshow/"+showid);
  }
 

}
