import { Component, OnInit } from '@angular/core';
import { MovieService } from '../movie.service';
import { Movie } from '../movie';
import { Location } from '@angular/common';

@Component({
  selector: 'app-addmovie',
  templateUrl: './addmovie.component.html',
  styleUrls: ['./addmovie.component.css']
})
export class AddmovieComponent implements OnInit {
  movie:Movie;
  newmovie:any
  message:String;

  constructor(private mservice:MovieService,private location: Location) { 
    this.movie=new Movie(0,"","","");
  }

  ngOnInit(): void {
  }

  public addmovie(){
    let response=this.mservice.addmovie(this.movie);
    response.subscribe(data=>
      {this.newmovie=data;
        this.message="movie added successfully"
      },
      error=>{
        this.message="enter valid movie details"
      }
    )
  }

  public goback(){
    this.location.back();
  }

}
