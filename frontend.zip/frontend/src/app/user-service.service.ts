import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { User } from './user';
import { Observable, BehaviorSubject } from 'rxjs';
 
@Injectable()
export class UserServiceService {
  // private messageSource = new BehaviorSubject('default message');
  // currentMessage = this.messageSource.asObservable();


  constructor(private http:HttpClient) { }

  public doregistration(user):Observable<any>{
    return this.http.post<any>("http://localhost:8888/user-service/customer",user,{responseType:"text" as "json"});

  }
  public getUsers(){
    return this.http.get("http://localhost:8888/user-service/Alluser");
  }

  public userloginpage(userlogin){
    return this.http.post("http://localhost:8888/user-service/login",userlogin,{responseType:"text" as "json"})

  }
  public loginUserFromRemote(user:User):Observable<any>{
    return this.http.post<any>("http://localhost:8888/user-service/login",user)
  }
 public removeuser(username){
  return this.http.get("http://localhost:8888/user-service/delete/"+username);
 }

 public getuserbyname(username){
   return this.http.get("http://localhost:8888/user-service/getuser/"+username);
 }

public updateuserbyname(user,username):Observable<any>{
  return this.http.put<any>("http://localhost:8888/user-service/user/"+username,user);

}

  
  // changeMessage(message: string) {
  //   this.messageSource.next(message)
  // }
}
